import 'dotenv/config';
import crypto from 'crypto';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  isSupabaseConfigured,
  sbCheckSubmissionStatus,
  sbDeleteSession,
  sbDeleteSessionSubmissions,
  sbFindSessionByIdOrCode,
  sbInsertSubmission,
  sbLoadStore,
  sbUpsertSession,
  subscribeSupabaseRealtime,
} from './src/lib/supabaseServer.ts';
import { buildProjectZipBuffer } from './src/lib/zipBuilder.ts';
import type {
  AttendeeSubmission,
  Session,
  SessionPulseStore,
} from './src/types/session.ts';

const ADMIN_CREDENTIAL_DIGEST =
  process.env.ADMIN_CREDENTIAL_DIGEST?.trim() ||
  'c4b9e68744d2e903cc95fa81df63231d47d8e10f5611c20d47ef5d6f7793615f';
const adminSessions = new Map<string, number>();

const PORT = Number(process.env.PORT) || 3000;
const DATA_FILE = path.resolve(process.cwd(), '.sessionpulse-data.json');

function loadDiskStore(): SessionPulseStore {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      return { sessions: [], submissions: [] };
    }
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<SessionPulseStore>;
    return {
      sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
      submissions: Array.isArray(parsed.submissions) ? parsed.submissions : [],
    };
  } catch {
    return { sessions: [], submissions: [] };
  }
}

function saveDiskStore(store: SessionPulseStore): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch {
    // Ignore write errors in read-only filesystems
  }
}

let store: SessionPulseStore = loadDiskStore();
const sseClients = new Set<express.Response>();

function broadcastStoreUpdate(): void {
  const payload = `data: ${JSON.stringify({ type: 'store_updated', ts: Date.now() })}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(payload);
    } catch {
      sseClients.delete(client);
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));
  const useSupabase = isSupabaseConfigured();

  // SSE stream for real-time live results across devices and tabs
  app.get('/api/events', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();
    res.write(`data: ${JSON.stringify({ type: 'connected' })}\n\n`);
    sseClients.add(res);

    const keepAlive = setInterval(() => {
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(keepAlive);
        sseClients.delete(res);
      }
    }, 25000);

    req.on('close', () => {
      clearInterval(keepAlive);
      sseClients.delete(res);
    });
  });

  // Fetch complete store (without exposing participant deduplication tokens)
  app.get('/api/store', async (_req, res) => {
    try {
      if (useSupabase) {
        const sbStore = await sbLoadStore();
        res.json(sbStore);
        return;
      }
      res.json({
        sessions: store.sessions,
        submissions: store.submissions.map(({ participantToken: _token, ...rest }) => rest),
      });
    } catch (error) {
      console.error('Failed to load store:', error);
      res.status(500).json({ error: 'Unable to load session data' });
    }
  });

  // Lookup a single session by ID or numeric join code (for QR & manual code entry)
  app.get('/api/sessions/:idOrCode', async (req, res) => {
    const query = String(req.params.idOrCode || '').trim();
    if (!query) {
      res.status(400).json({ error: 'Missing session identifier' });
      return;
    }
    try {
      if (useSupabase) {
        const found = await sbFindSessionByIdOrCode(query);
        if (!found) {
          res.status(404).json({ error: 'Session not found' });
          return;
        }
        res.json({ session: found });
        return;
      }

      const upper = query.toUpperCase();
      const found = store.sessions.find(
        (s) => s.id === query || s.code.toUpperCase() === upper
      );
      if (!found) {
        res.status(404).json({ error: 'Session not found' });
        return;
      }
      res.json({ session: found });
    } catch (error) {
      console.error('Failed to find session:', error);
      res.status(500).json({ error: 'Unable to look up session' });
    }
  });

  const sanitizeSession = (incoming: Session): Session => {
    if (!Array.isArray(incoming.questions)) {
      return { ...incoming, questions: [] };
    }
    if (incoming.activityType === 'poll') {
      return {
        ...incoming,
        questions: incoming.questions.filter(
          (q) => q.kind === 'yes_no' || q.kind === 'mcq'
        ),
      };
    }
    if (incoming.activityType === 'opinion') {
      return {
        ...incoming,
        questions: incoming.questions.filter((q) => q.kind === 'descriptive'),
      };
    }
    return incoming;
  };

  // Create session
  app.post('/api/sessions', async (req, res) => {
    const incoming = req.body?.session as Session | undefined;
    if (
      !incoming ||
      typeof incoming.id !== 'string' ||
      typeof incoming.title !== 'string' ||
      typeof incoming.code !== 'string' ||
      !['poll', 'quiz', 'opinion'].includes(incoming.activityType)
    ) {
      res.status(400).json({ error: 'Invalid session payload' });
      return;
    }
    const sanitizedSession = sanitizeSession(incoming);

    try {
      if (useSupabase) {
        const saved = await sbUpsertSession(sanitizedSession);
        broadcastStoreUpdate();
        res.status(201).json({ session: saved });
        return;
      }

      const exists = store.sessions.some((s) => s.id === sanitizedSession.id);
      store = {
        ...store,
        sessions: exists
          ? store.sessions.map((s) =>
              s.id === sanitizedSession.id ? sanitizedSession : s
            )
          : [sanitizedSession, ...store.sessions],
      };
      saveDiskStore(store);
      broadcastStoreUpdate();
      res.status(201).json({ session: sanitizedSession });
    } catch (error) {
      console.error('Failed to create session:', error);
      res.status(500).json({ error: 'Unable to save session' });
    }
  });

  // Update session
  app.put('/api/sessions/:id', async (req, res) => {
    const id = String(req.params.id || '');
    const incoming = req.body?.session as Session | undefined;
    if (
      !incoming ||
      incoming.id !== id ||
      typeof incoming.title !== 'string' ||
      !['poll', 'quiz', 'opinion'].includes(incoming.activityType)
    ) {
      res.status(400).json({ error: 'Invalid session update payload' });
      return;
    }
    const sanitizedSession = sanitizeSession(incoming);

    try {
      if (useSupabase) {
        const saved = await sbUpsertSession(sanitizedSession);
        broadcastStoreUpdate();
        res.json({ session: saved });
        return;
      }

      const exists = store.sessions.some((s) => s.id === id);
      store = {
        ...store,
        sessions: exists
          ? store.sessions.map((s) => (s.id === id ? sanitizedSession : s))
          : [sanitizedSession, ...store.sessions],
      };
      saveDiskStore(store);
      broadcastStoreUpdate();
      res.json({ session: sanitizedSession });
    } catch (error) {
      console.error('Failed to update session:', error);
      res.status(500).json({ error: 'Unable to update session' });
    }
  });

  // Delete session & its submissions
  app.delete('/api/sessions/:id', async (req, res) => {
    const id = String(req.params.id || '').trim();
    if (!id) {
      res.status(400).json({ error: 'Missing session id' });
      return;
    }
    try {
      if (useSupabase) {
        await sbDeleteSession(id);
        broadcastStoreUpdate();
        res.json({ ok: true });
        return;
      }

      store = {
        sessions: store.sessions.filter((s) => s.id !== id),
        submissions: store.submissions.filter((sub) => sub.sessionId !== id),
      };
      saveDiskStore(store);
      broadcastStoreUpdate();
      res.json({ ok: true });
    } catch (error) {
      console.error('Failed to delete session:', error);
      res.status(500).json({ error: 'Unable to delete session' });
    }
  });

  // Check whether a participant token has already recorded a response for a session
  app.get('/api/submissions/status', async (req, res) => {
    const sessionId = String(req.query.sessionId || '').trim();
    const participantToken = String(req.query.participantToken || '').trim();
    if (!sessionId || !participantToken) {
      res.json({ alreadySubmitted: false });
      return;
    }

    try {
      if (useSupabase) {
        const status = await sbCheckSubmissionStatus(sessionId, participantToken);
        res.json(status);
        return;
      }

      const existing = store.submissions.find(
        (sub) =>
          sub.sessionId === sessionId &&
          sub.participantToken === participantToken
      );
      if (!existing) {
        res.json({ alreadySubmitted: false });
        return;
      }
      res.json({
        alreadySubmitted: true,
        ...(existing.quizScore ? { quizScore: existing.quizScore } : {}),
      });
    } catch (error) {
      console.error('Failed to check submission status:', error);
      res.status(500).json({ error: 'Unable to verify submission status' });
    }
  });

  // Submit anonymous attendee response (at most once per participant per session)
  app.post('/api/submissions', async (req, res) => {
    const submission = req.body?.submission as AttendeeSubmission | undefined;
    if (
      !submission ||
      typeof submission.id !== 'string' ||
      typeof submission.sessionId !== 'string' ||
      typeof submission.answers !== 'object' ||
      submission.answers === null
    ) {
      res.status(400).json({ error: 'Invalid submission payload' });
      return;
    }

    try {
      if (useSupabase) {
        const result = await sbInsertSubmission(submission);
        if (result.status === 'not_found') {
          res.status(404).json({ error: 'Session not found' });
          return;
        }
        if (result.status === 'ended') {
          res.status(409).json({ error: 'This session has ended' });
          return;
        }
        if (result.status === 'duplicate') {
          res.status(409).json({
            error: 'You have already submitted a response for this session.',
            alreadySubmitted: true,
          });
          return;
        }
        broadcastStoreUpdate();
        res.status(201).json({ submission: result.submission });
        return;
      }

      const targetSession = store.sessions.find((s) => s.id === submission.sessionId);
      if (!targetSession) {
        res.status(404).json({ error: 'Session not found' });
        return;
      }
      if (targetSession.status === 'ended') {
        res.status(409).json({ error: 'This session has ended' });
        return;
      }

      const token =
        typeof submission.participantToken === 'string'
          ? submission.participantToken.trim()
          : '';
      if (token) {
        const duplicate = store.submissions.some(
          (sub) => sub.sessionId === submission.sessionId && sub.participantToken === token
        );
        if (duplicate) {
          res.status(409).json({
            error: 'You have already submitted a response for this session.',
            alreadySubmitted: true,
          });
          return;
        }
      }

      const sanitizedAnswers: Record<string, string | string[]> = {};
      for (const [qId, val] of Object.entries(submission.answers ?? {})) {
        if (typeof val === 'string') {
          sanitizedAnswers[qId] =
            targetSession.activityType === 'opinion' ? val.slice(0, 200) : val;
        } else if (Array.isArray(val)) {
          sanitizedAnswers[qId] = val.filter((item) => typeof item === 'string');
        }
      }

      const sanitizedSubmission: AttendeeSubmission = {
        ...submission,
        answers: sanitizedAnswers,
      };

      store = {
        ...store,
        submissions: [...store.submissions, sanitizedSubmission],
      };
      saveDiskStore(store);
      broadcastStoreUpdate();
      res.status(201).json({ submission: sanitizedSubmission });
    } catch (error) {
      console.error('Failed to submit response:', error);
      res.status(500).json({ error: 'Unable to save response' });
    }
  });

  // Reset submissions for a session
  app.delete('/api/sessions/:id/submissions', async (req, res) => {
    const id = String(req.params.id || '').trim();
    if (!id) {
      res.status(400).json({ error: 'Missing session id' });
      return;
    }
    try {
      if (useSupabase) {
        await sbDeleteSessionSubmissions(id);
        broadcastStoreUpdate();
        res.json({ ok: true });
        return;
      }

      store = {
        ...store,
        submissions: store.submissions.filter((sub) => sub.sessionId !== id),
      };
      saveDiskStore(store);
      broadcastStoreUpdate();
      res.json({ ok: true });
    } catch (error) {
      console.error('Failed to reset submissions:', error);
      res.status(500).json({ error: 'Unable to reset session responses' });
    }
  });

  // Admin login token endpoint (for protected admin-only exports)
  app.post('/api/admin/login', (req, res) => {
    const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!email || !password) {
      res.status(400).json({ error: 'Missing credentials' });
      return;
    }

    const digestHex = crypto
      .createHash('sha256')
      .update(`${email}:${password}`)
      .digest('hex');

    const a = Buffer.from(digestHex, 'utf8');
    const b = Buffer.from(ADMIN_CREDENTIAL_DIGEST, 'utf8');
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const token = crypto.randomUUID();
    adminSessions.set(token, Date.now() + 12 * 60 * 60 * 1000);
    res.json({ token });
  });

  // Admin-only downloadable ZIP archive of site source files (excludes secrets & build dirs)
  app.get('/api/admin/download-code', (req, res) => {
    const authHeader = String(req.headers.authorization || '');
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
    const expiresAt = token ? adminSessions.get(token) : undefined;
    if (!expiresAt || expiresAt < Date.now()) {
      if (token) adminSessions.delete(token);
      res.status(401).json({ error: 'Admin authentication required' });
      return;
    }

    try {
      const zipBuffer = buildProjectZipBuffer(process.cwd(), 'sessionpulse');
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="sessionpulse-code.zip"'
      );
      res.setHeader('Cache-Control', 'no-store');
      res.send(zipBuffer);
    } catch (error) {
      console.error('Failed to build source archive:', error);
      res.status(500).json({ error: 'Unable to package source files' });
    }
  });

  if (useSupabase) {
    subscribeSupabaseRealtime(() => {
      broadcastStoreUpdate();
    });
  }

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(
      `SessionPulse server running on http://0.0.0.0:${PORT} (${
        useSupabase
          ? 'Supabase + Realtime active'
          : 'local JSON fallback — set SUPABASE_URL & SUPABASE_SECRET_KEY to enable Supabase'
      })`
    );
  });
}

startServer();
