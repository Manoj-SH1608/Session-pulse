-- SessionPulse Supabase Schema, Readable User Answers, Realtime & RLS Policies
-- Run this script in your Supabase Dashboard -> SQL Editor (safe & idempotent to re-run).

-- 1. Sessions Table (Polls, Quizzes, Opinions)
CREATE TABLE IF NOT EXISTS public.sessions (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  presenter TEXT NOT NULL DEFAULT '',
  activity_type TEXT NOT NULL CHECK (activity_type IN ('poll', 'quiz', 'opinion')),
  created_at BIGINT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
  confirmed BOOLEAN NOT NULL DEFAULT FALSE,
  questions JSONB NOT NULL DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS sessions_code_idx ON public.sessions (code);
CREATE INDEX IF NOT EXISTS sessions_created_at_idx ON public.sessions (created_at DESC);

-- 2. Submissions Table (Anonymous Attendee Responses)
CREATE TABLE IF NOT EXISTS public.submissions (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  submitted_at BIGINT NOT NULL,
  participant_token TEXT,
  answers JSONB NOT NULL DEFAULT '{}'::jsonb,
  selected_answers JSONB NOT NULL DEFAULT '[]'::jsonb,
  quiz_score JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.submissions
  ADD COLUMN IF NOT EXISTS selected_answers JSONB NOT NULL DEFAULT '[]'::jsonb;

CREATE INDEX IF NOT EXISTS submissions_session_id_idx ON public.submissions (session_id);

-- Enforce one survey submission per participant token per session at the database level
CREATE UNIQUE INDEX IF NOT EXISTS submissions_unique_session_participant
  ON public.submissions (session_id, participant_token)
  WHERE participant_token IS NOT NULL AND participant_token <> '';

-- 3. Submission Answers Table (Human-readable answers selected and given by each user)
CREATE TABLE IF NOT EXISTS public.submission_answers (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL REFERENCES public.submissions(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  session_title TEXT NOT NULL DEFAULT '',
  session_code TEXT NOT NULL DEFAULT '',
  activity_type TEXT NOT NULL CHECK (activity_type IN ('poll', 'quiz', 'opinion')),
  question_id TEXT NOT NULL,
  question_prompt TEXT NOT NULL,
  question_kind TEXT NOT NULL CHECK (question_kind IN ('yes_no', 'mcq', 'descriptive')),
  selected_option_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
  selected_answer_texts JSONB NOT NULL DEFAULT '[]'::jsonb,
  given_answer TEXT NOT NULL DEFAULT '',
  is_correct BOOLEAN,
  submitted_at BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS submission_answers_session_id_idx ON public.submission_answers (session_id);
CREATE INDEX IF NOT EXISTS submission_answers_submission_id_idx ON public.submission_answers (submission_id);
CREATE UNIQUE INDEX IF NOT EXISTS submission_answers_unique_sub_question
  ON public.submission_answers (submission_id, question_id);

-- 4. Enable Supabase Realtime for live updates
ALTER TABLE public.sessions REPLICA IDENTITY FULL;
ALTER TABLE public.submissions REPLICA IDENTITY FULL;
ALTER TABLE public.submission_answers REPLICA IDENTITY FULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication
    WHERE pubname = 'supabase_realtime'
  ) THEN
    CREATE PUBLICATION supabase_realtime;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'sessions'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.sessions;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'submissions'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.submissions;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'submission_answers'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.submission_answers;
  END IF;
END $$;

-- 5. Enable Row Level Security (RLS)
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.submission_answers ENABLE ROW LEVEL SECURITY;

-- 6. Row Level Security Policies

-- Sessions: Anyone with a QR link / join code can read sessions,
-- while only authenticated admins or the server (secret/service_role key) can create, edit, or delete sessions.
DROP POLICY IF EXISTS "Public can read sessions" ON public.sessions;
CREATE POLICY "Public can read sessions"
  ON public.sessions
  FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "Authenticated users can manage sessions" ON public.sessions;
CREATE POLICY "Authenticated users can manage sessions"
  ON public.sessions
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Submissions: Attendees can insert a response only into an active session.
-- Reading raw submissions (which contain participant_token) and resetting/deleting responses
-- are restricted to authenticated admins and the backend server (secret/service_role key).
DROP POLICY IF EXISTS "Attendees can submit to active sessions" ON public.submissions;
CREATE POLICY "Attendees can submit to active sessions"
  ON public.submissions
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM public.sessions s
      WHERE s.id = session_id
        AND s.status = 'active'
    )
  );

DROP POLICY IF EXISTS "Authenticated users can read submissions" ON public.submissions;
CREATE POLICY "Authenticated users can read submissions"
  ON public.submissions
  FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Authenticated users can delete submissions" ON public.submissions;
CREATE POLICY "Authenticated users can delete submissions"
  ON public.submissions
  FOR DELETE
  TO authenticated
  USING (true);

-- Submission Answers: Attendees can insert readable answers for active sessions.
-- Reading and deleting answers are restricted to authenticated admins and the backend server.
DROP POLICY IF EXISTS "Attendees can insert answers for active sessions" ON public.submission_answers;
CREATE POLICY "Attendees can insert answers for active sessions"
  ON public.submission_answers
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM public.sessions s
      WHERE s.id = session_id
        AND s.status = 'active'
    )
  );

DROP POLICY IF EXISTS "Authenticated users can read submission answers" ON public.submission_answers;
CREATE POLICY "Authenticated users can read submission answers"
  ON public.submission_answers
  FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Authenticated users can delete submission answers" ON public.submission_answers;
CREATE POLICY "Authenticated users can delete submission answers"
  ON public.submission_answers
  FOR DELETE
  TO authenticated
  USING (true);

-- 7. Backfill readable answers for any existing submissions already stored in public.submissions
INSERT INTO public.submission_answers (
  id,
  submission_id,
  session_id,
  session_title,
  session_code,
  activity_type,
  question_id,
  question_prompt,
  question_kind,
  selected_option_ids,
  selected_answer_texts,
  given_answer,
  is_correct,
  submitted_at
)
SELECT
  sub.id || '_' || (q->>'id') AS id,
  sub.id AS submission_id,
  s.id AS session_id,
  s.title AS session_title,
  s.code AS session_code,
  s.activity_type,
  q->>'id' AS question_id,
  COALESCE(q->>'prompt', '') AS question_prompt,
  COALESCE(q->>'kind', 'descriptive') AS question_kind,
  CASE
    WHEN (q->>'kind') = 'descriptive' THEN '[]'::jsonb
    WHEN jsonb_typeof(sub.answers -> (q->>'id')) = 'array' THEN sub.answers -> (q->>'id')
    WHEN jsonb_typeof(sub.answers -> (q->>'id')) = 'string' THEN jsonb_build_array(sub.answers ->> (q->>'id'))
    ELSE '[]'::jsonb
  END AS selected_option_ids,
  CASE
    WHEN (q->>'kind') = 'descriptive' THEN '[]'::jsonb
    WHEN jsonb_typeof(sub.answers -> (q->>'id')) = 'array' THEN COALESCE(
      (
        SELECT jsonb_agg(COALESCE(opt->>'text', elem.val))
        FROM jsonb_array_elements_text(sub.answers -> (q->>'id')) AS elem(val)
        LEFT JOIN jsonb_array_elements(COALESCE(q->'options', '[]'::jsonb)) AS opt
          ON (opt->>'id') = elem.val
      ),
      '[]'::jsonb
    )
    WHEN jsonb_typeof(sub.answers -> (q->>'id')) = 'string' THEN jsonb_build_array(
      COALESCE(
        (
          SELECT opt->>'text'
          FROM jsonb_array_elements(COALESCE(q->'options', '[]'::jsonb)) AS opt
          WHERE (opt->>'id') = (sub.answers ->> (q->>'id'))
          LIMIT 1
        ),
        sub.answers ->> (q->>'id')
      )
    )
    ELSE '[]'::jsonb
  END AS selected_answer_texts,
  CASE
    WHEN (q->>'kind') = 'descriptive' THEN COALESCE(sub.answers ->> (q->>'id'), '')
    WHEN jsonb_typeof(sub.answers -> (q->>'id')) = 'array' THEN COALESCE(
      (
        SELECT string_agg(COALESCE(opt->>'text', elem.val), ', ')
        FROM jsonb_array_elements_text(sub.answers -> (q->>'id')) AS elem(val)
        LEFT JOIN jsonb_array_elements(COALESCE(q->'options', '[]'::jsonb)) AS opt
          ON (opt->>'id') = elem.val
      ),
      ''
    )
    WHEN jsonb_typeof(sub.answers -> (q->>'id')) = 'string' THEN COALESCE(
      (
        SELECT opt->>'text'
        FROM jsonb_array_elements(COALESCE(q->'options', '[]'::jsonb)) AS opt
        WHERE (opt->>'id') = (sub.answers ->> (q->>'id'))
        LIMIT 1
      ),
      sub.answers ->> (q->>'id'),
      ''
    )
    ELSE ''
  END AS given_answer,
  CASE
    WHEN s.activity_type = 'quiz'
      AND COALESCE(q->>'correctOptionId', '') <> ''
      AND (q->>'kind') IN ('yes_no', 'mcq')
      AND jsonb_typeof(sub.answers -> (q->>'id')) = 'string'
    THEN (sub.answers ->> (q->>'id')) = (q->>'correctOptionId')
    ELSE NULL
  END AS is_correct,
  sub.submitted_at
FROM public.submissions sub
JOIN public.sessions s ON s.id = sub.session_id
CROSS JOIN LATERAL jsonb_array_elements(COALESCE(s.questions, '[]'::jsonb)) AS q
WHERE sub.answers ? (q->>'id')
ON CONFLICT (submission_id, question_id) DO NOTHING;

UPDATE public.submissions sub
SET selected_answers = COALESCE(
  (
    SELECT jsonb_agg(
      jsonb_build_object(
        'question_id', sa.question_id,
        'question_prompt', sa.question_prompt,
        'question_kind', sa.question_kind,
        'selected_option_ids', sa.selected_option_ids,
        'selected_answer_texts', sa.selected_answer_texts,
        'given_answer', sa.given_answer,
        'is_correct', sa.is_correct
      )
    )
    FROM public.submission_answers sa
    WHERE sa.submission_id = sub.id
  ),
  '[]'::jsonb
)
WHERE jsonb_array_length(COALESCE(sub.selected_answers, '[]'::jsonb)) = 0;
