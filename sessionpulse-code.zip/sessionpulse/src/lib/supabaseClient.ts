import { createClient, type SupabaseClient } from '@supabase/supabase-js';

function normalizeSupabaseUrl(raw: string): string {
  const trimmed = raw.trim().replace(/\/+$/, '');
  if (!trimmed) return '';
  const dashboardMatch = trimmed.match(
    /^https?:\/\/supabase\.com\/dashboard\/project\/([a-z0-9_-]+)/i
  );
  if (dashboardMatch?.[1]) {
    return `https://${dashboardMatch[1]}.supabase.co`;
  }
  return trimmed;
}

const publicUrl = normalizeSupabaseUrl(import.meta.env.VITE_SUPABASE_URL || '');
const publicAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim() || '';

let browserClient: SupabaseClient | null = null;

export function getSupabaseBrowserClient(): SupabaseClient | null {
  if (!publicUrl || !publicAnonKey) return null;
  if (!browserClient) {
    browserClient = createClient(publicUrl, publicAnonKey);
  }
  return browserClient;
}

/**
 * Optional client-side Supabase Realtime listener when public VITE_SUPABASE_* keys
 * are configured alongside the server-side SSE stream.
 */
export function subscribeSupabaseClientRealtime(
  onUpdate: () => void
): () => void {
  const client = getSupabaseBrowserClient();
  if (!client) return () => {};

  const channel = client
    .channel('sessionpulse-client-realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'sessions' },
      () => onUpdate()
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'submissions' },
      () => onUpdate()
    )
    .subscribe();

  return () => {
    void client.removeChannel(channel);
  };
}
