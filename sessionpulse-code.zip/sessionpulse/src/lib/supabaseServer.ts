import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type {
  AttendeeSubmission,
  Session,
  SessionPulseStore,
  SessionQuestion,
} from '../types/session.ts';

interface SessionRow {
  id: string;
  code: string;
  title: string;
  presenter: string;
  activity_type: Session['activityType'];
  created_at: number;
  status: Session['status'];
  confirmed: boolean;
  questions: SessionQuestion[];
}

interface DetailedAnswerRecord {
  question_id: string;
  question_prompt: string;
  question_kind: SessionQuestion['kind'];
  selected_option_ids: string[];
  selected_answer_texts: string[];
  given_answer: string;
  is_correct: boolean | null;
}

interface SubmissionRow {
  id: string;
  session_id: string;
  submitted_at: number;
  participant_token?: string | null;
  answers: Record<string, string | string[]>;
  selected_answers?: DetailedAnswerRecord[];
  quiz_score?: { score: number; total: number } | null;
}

interface SubmissionAnswerRow {
  id: string;
  submission_id: string;
  session_id: string;
  session_title: string;
  session_code: string;
  activity_type: Session['activityType'];
  question_id: string;
  question_prompt: string;
  question_kind: SessionQuestion['kind'];
  selected_option_ids: string[];
  selected_answer_texts: string[];
  given_answer: string;
  is_correct: boolean | null;
  submitted_at: number;
}

function normalizeSupabaseUrl(raw: string): string {
  const trimmed = raw.trim().replace(/\/+$/, '');
  if (!trimmed) return '';
  const dashboardMatch = trimmed.match(
    /^https?:\/\/supabase\.com\/dashboard\/project\/([a-z0-9_-]+)/i
  );
  if (dashboardMatch?.[1]) {
    return `https://${dashboardMatch[1]}.supabase.co`;
  }
  return trimmed;
}

function getSupabaseConfig(): { url: string; secretKey: string } {
  return {
    url: normalizeSupabaseUrl(process.env.SUPABASE_URL || ''),
    secretKey:
      process.env.SUPABASE_SECRET_KEY?.trim() ||
      process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
      '',
  };
}

let client: SupabaseClient | null = null;

export function isSupabaseConfigured(): boolean {
  const { url, secretKey } = getSupabaseConfig();
  return Boolean(url && secretKey);
}

export function getSupabaseServerClient(): SupabaseClient | null {
  const { url, secretKey } = getSupabaseConfig();
  if (!url || !secretKey) return null;
  if (!client) {
    client = createClient(url, secretKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });
  }
  return client;
}

function mapSessionRow(row: SessionRow): Session {
  return {
    id: row.id,
    code: row.code,
    title: row.title,
    presenter: row.presenter ?? '',
    activityType: row.activity_type,
    createdAt: Number(row.created_at),
    status: row.status,
    confirmed: Boolean(row.confirmed),
    questions: Array.isArray(row.questions) ? row.questions : [],
  };
}

function toSessionRow(session: Session): SessionRow {
  return {
    id: session.id,
    code: session.code,
    title: session.title,
    presenter: session.presenter ?? '',
    activity_type: session.activityType,
    created_at: session.createdAt,
    status: session.status,
    confirmed: Boolean(session.confirmed),
    questions: session.questions,
  };
}

function mapSubmissionRow(row: SubmissionRow): AttendeeSubmission {
  return {
    id: row.id,
    sessionId: row.session_id,
    submittedAt: Number(row.submitted_at),
    answers: row.answers ?? {},
    ...(row.quiz_score ? { quizScore: row.quiz_score } : {}),
  };
}

export async function sbLoadStore(): Promise<SessionPulseStore> {
  const sb = getSupabaseServerClient();
  if (!sb) throw new Error('Supabase is not configured');

  const [sessionsRes, submissionsRes] = await Promise.all([
    sb
      .from('sessions')
      .select('id, code, title, presenter, activity_type, created_at, status, confirmed, questions')
      .order('created_at', { ascending: false }),
    sb
      .from('submissions')
      .select('id, session_id, submitted_at, answers, quiz_score')
      .order('submitted_at', { ascending: true }),
  ]);

  if (sessionsRes.error) throw sessionsRes.error;
  if (submissionsRes.error) throw submissionsRes.error;

  return {
    sessions: ((sessionsRes.data ?? []) as SessionRow[]).map(mapSessionRow),
    submissions: ((submissionsRes.data ?? []) as SubmissionRow[]).map(mapSubmissionRow),
  };
}

export async function sbFindSessionByIdOrCode(
  idOrCode: string
): Promise<Session | null> {
  const sb = getSupabaseServerClient();
  if (!sb) throw new Error('Supabase is not configured');

  const trimmed = idOrCode.trim();
  const { data: byId, error: idErr } = await sb
    .from('sessions')
    .select('id, code, title, presenter, activity_type, created_at, status, confirmed, questions')
    .eq('id', trimmed)
    .maybeSingle();

  if (idErr) throw idErr;
  if (byId) return mapSessionRow(byId as SessionRow);

  const { data: byCode, error: codeErr } = await sb
    .from('sessions')
    .select('id, code, title, presenter, activity_type, created_at, status, confirmed, questions')
    .ilike('code', trimmed)
    .maybeSingle();

  if (codeErr) throw codeErr;
  return byCode ? mapSessionRow(byCode as SessionRow) : null;
}

export async function sbUpsertSession(session: Session): Promise<Session> {
  const sb = getSupabaseServerClient();
  if (!sb) throw new Error('Supabase is not configured');

  const { data, error } = await sb
    .from('sessions')
    .upsert(toSessionRow(session), { onConflict: 'id' })
    .select('id, code, title, presenter, activity_type, created_at, status, confirmed, questions')
    .single();

  if (error) throw error;
  return mapSessionRow(data as SessionRow);
}

export async function sbDeleteSession(sessionId: string): Promise<void> {
  const sb = getSupabaseServerClient();
  if (!sb) throw new Error('Supabase is not configured');

  const { error } = await sb.from('sessions').delete().eq('id', sessionId);
  if (error) throw error;
}

export async function sbCheckSubmissionStatus(
  sessionId: string,
  participantToken: string
): Promise<{
  alreadySubmitted: boolean;
  quizScore?: { score: number; total: number };
}> {
  const sb = getSupabaseServerClient();
  if (!sb) throw new Error('Supabase is not configured');

  const { data, error } = await sb
    .from('submissions')
    .select('quiz_score')
    .eq('session_id', sessionId)
    .eq('participant_token', participantToken)
    .maybeSingle();

  if (error) throw error;
  if (!data) return { alreadySubmitted: false };

  const row = data as { quiz_score?: { score: number; total: number } | null };
  return {
    alreadySubmitted: true,
    ...(row.quiz_score ? { quizScore: row.quiz_score } : {}),
  };
}

function buildDetailedAnswers(
  questions: SessionQuestion[],
  activityType: Session['activityType'],
  sanitizedAnswers: Record<string, string | string[]>
): DetailedAnswerRecord[] {
  const results: DetailedAnswerRecord[] = [];
  const handledQuestionIds = new Set<string>();

  for (const q of questions) {
    const raw = sanitizedAnswers[q.id];
    if (raw === undefined) continue;
    handledQuestionIds.add(q.id);

    if (q.kind === 'descriptive') {
      const text = typeof raw === 'string' ? raw : '';
      results.push({
        question_id: q.id,
        question_prompt: q.prompt,
        question_kind: q.kind,
        selected_option_ids: [],
        selected_answer_texts: [],
        given_answer: text,
        is_correct: null,
      });
      continue;
    }

    const optionIds = Array.isArray(raw)
      ? raw
      : typeof raw === 'string' && raw.length > 0
        ? [raw]
        : [];
    const optionTexts = optionIds.map(
      (oid) => q.options.find((opt) => opt.id === oid)?.text ?? oid
    );
    const isGradable =
      activityType === 'quiz' &&
      Boolean(q.correctOptionId) &&
      !q.allowMultiple &&
      optionIds.length === 1;

    results.push({
      question_id: q.id,
      question_prompt: q.prompt,
      question_kind: q.kind,
      selected_option_ids: optionIds,
      selected_answer_texts: optionTexts,
      given_answer: optionTexts.join(', '),
      is_correct: isGradable ? optionIds[0] === q.correctOptionId : null,
    });
  }

  for (const [qId, raw] of Object.entries(sanitizedAnswers)) {
    if (handledQuestionIds.has(qId)) continue;
    const isArray = Array.isArray(raw);
    const optionIds = isArray ? raw : [];
    const givenAnswer = isArray ? raw.join(', ') : String(raw);
    results.push({
      question_id: qId,
      question_prompt: qId,
      question_kind: isArray ? 'mcq' : 'descriptive',
      selected_option_ids: optionIds,
      selected_answer_texts: optionIds,
      given_answer: givenAnswer,
      is_correct: null,
    });
  }

  return results;
}

export async function sbInsertSubmission(
  submission: AttendeeSubmission
): Promise<{
  status: 'created' | 'not_found' | 'ended' | 'duplicate';
  submission?: AttendeeSubmission;
}> {
  const sb = getSupabaseServerClient();
  if (!sb) throw new Error('Supabase is not configured');

  const { data: sessionRow, error: sesErr } = await sb
    .from('sessions')
    .select('id, code, title, status, activity_type, questions')
    .eq('id', submission.sessionId)
    .maybeSingle();

  if (sesErr) throw sesErr;
  if (!sessionRow) return { status: 'not_found' };
  const target = sessionRow as {
    id: string;
    code: string;
    title: string;
    status: Session['status'];
    activity_type: Session['activityType'];
    questions: SessionQuestion[];
  };
  if (target.status === 'ended') return { status: 'ended' };

  const token =
    typeof submission.participantToken === 'string'
      ? submission.participantToken.trim()
      : '';

  if (token) {
    const existing = await sbCheckSubmissionStatus(submission.sessionId, token);
    if (existing.alreadySubmitted) {
      return { status: 'duplicate' };
    }
  }

  const sanitizedAnswers: Record<string, string | string[]> = {};
  for (const [qId, val] of Object.entries(submission.answers ?? {})) {
    if (typeof val === 'string') {
      sanitizedAnswers[qId] =
        target.activity_type === 'opinion' ? val.slice(0, 200) : val;
    } else if (Array.isArray(val)) {
      sanitizedAnswers[qId] = val.filter((item) => typeof item === 'string');
    }
  }

  const detailedAnswers = buildDetailedAnswers(
    Array.isArray(target.questions) ? target.questions : [],
    target.activity_type,
    sanitizedAnswers
  );

  const rowWithDetails: SubmissionRow = {
    id: submission.id,
    session_id: submission.sessionId,
    submitted_at: submission.submittedAt,
    participant_token: token || null,
    answers: sanitizedAnswers,
    selected_answers: detailedAnswers,
    quiz_score: submission.quizScore ?? null,
  };

  let { data, error } = await sb
    .from('submissions')
    .insert(rowWithDetails)
    .select('id, session_id, submitted_at, answers, quiz_score')
    .single();

  // Backward compatibility if selected_answers column has not been added via schema.sql yet
  if (
    error &&
    (error.code === 'PGRST204' ||
      error.code === '42703' ||
      error.message?.includes('selected_answers'))
  ) {
    const legacyRow: SubmissionRow = {
      id: submission.id,
      session_id: submission.sessionId,
      submitted_at: submission.submittedAt,
      participant_token: token || null,
      answers: sanitizedAnswers,
      quiz_score: submission.quizScore ?? null,
    };
    const retry = await sb
      .from('submissions')
      .insert(legacyRow)
      .select('id, session_id, submitted_at, answers, quiz_score')
      .single();
    data = retry.data;
    error = retry.error;
  }

  if (error) {
    // Handle unique constraint violation (23505) on concurrent duplicate submit
    if (error.code === '23505') {
      return { status: 'duplicate' };
    }
    throw error;
  }

  if (detailedAnswers.length > 0) {
    const answerRows: SubmissionAnswerRow[] = detailedAnswers.map((item) => ({
      id: `${submission.id}_${item.question_id}`,
      submission_id: submission.id,
      session_id: submission.sessionId,
      session_title: target.title ?? '',
      session_code: target.code ?? '',
      activity_type: target.activity_type,
      question_id: item.question_id,
      question_prompt: item.question_prompt,
      question_kind: item.question_kind,
      selected_option_ids: item.selected_option_ids,
      selected_answer_texts: item.selected_answer_texts,
      given_answer: item.given_answer,
      is_correct: item.is_correct,
      submitted_at: submission.submittedAt,
    }));

    const { error: ansErr } = await sb
      .from('submission_answers')
      .insert(answerRows);

    if (
      ansErr &&
      ansErr.code !== '42P01' &&
      ansErr.code !== 'PGRST205' &&
      !ansErr.message?.includes('submission_answers')
    ) {
      console.error('Failed to insert readable submission_answers:', ansErr);
    }
  }

  return {
    status: 'created',
    submission: mapSubmissionRow(data as SubmissionRow),
  };
}

export async function sbDeleteSessionSubmissions(
  sessionId: string
): Promise<void> {
  const sb = getSupabaseServerClient();
  if (!sb) throw new Error('Supabase is not configured');

  const { error } = await sb
    .from('submissions')
    .delete()
    .eq('session_id', sessionId);
  if (error) throw error;
}

export function subscribeSupabaseRealtime(onChange: () => void): () => void {
  const sb = getSupabaseServerClient();
  if (!sb) return () => {};

  const channel = sb
    .channel('sessionpulse-server-realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'sessions' },
      () => onChange()
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'submissions' },
      () => onChange()
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'submission_answers' },
      () => onChange()
    )
    .subscribe();

  return () => {
    void sb.removeChannel(channel);
  };
}
