import type {
  ActivityType,
  AttendeeSubmission,
  QuestionKind,
  Session,
  SessionPulseStore,
  SessionQuestion,
} from '../types/session';
import { subscribeSupabaseClientRealtime } from './supabaseClient';

const STORAGE_KEY = 'sessionpulse_v3';
const CHANNEL_NAME = 'sessionpulse_sync_v3';

export function generateId(prefix = 'id'): string {
  const rand = Math.random().toString(36).slice(2, 8);
  const ts = Date.now().toString(36);
  return `${prefix}_${ts}_${rand}`;
}

export function generateSessionCode(existingCodes: string[] = []): string {
  const used = new Set(existingCodes.map((c) => c.trim()));
  for (let attempt = 0; attempt < 50; attempt += 1) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    if (!used.has(code)) {
      return code;
    }
  }
  return String(Math.floor(100000 + Math.random() * 900000));
}

function toBase64Url(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromBase64Url(b64url: string): string {
  const base64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
  const pad = base64.length % 4 === 0 ? '' : '='.repeat(4 - (base64.length % 4));
  const binary = atob(`${base64}${pad}`);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

interface CompactSessionPayload {
  i: string;
  c: string;
  t: string;
  p: string;
  a: ActivityType;
  ts: number;
  q: Array<{
    i: string;
    k: QuestionKind;
    p: string;
    m?: boolean;
    co?: string;
    ex?: string;
    ph?: string;
    o: Array<{ i: string; t: string }>;
  }>;
}

export function encodeSessionPayload(session: Session): string {
  try {
    const compact: CompactSessionPayload = {
      i: session.id,
      c: session.code,
      t: session.title,
      p: session.presenter,
      a: session.activityType,
      ts: session.createdAt,
      q: session.questions.map((item) => ({
        i: item.id,
        k: item.kind,
        p: item.prompt,
        ...(item.allowMultiple ? { m: true } : {}),
        ...(item.correctOptionId ? { co: item.correctOptionId } : {}),
        ...(item.explanation ? { ex: item.explanation } : {}),
        ...(item.placeholder ? { ph: item.placeholder } : {}),
        o: item.options.map((opt) => ({ i: opt.id, t: opt.text })),
      })),
    };
    return toBase64Url(JSON.stringify(compact));
  } catch {
    return '';
  }
}

export function decodeSessionPayload(encoded: string): Session | null {
  if (!encoded || !encoded.trim()) return null;
  try {
    const parsed = JSON.parse(fromBase64Url(encoded.trim())) as Partial<CompactSessionPayload>;
    if (
      !parsed ||
      typeof parsed.i !== 'string' ||
      typeof parsed.c !== 'string' ||
      typeof parsed.t !== 'string' ||
      !['poll', 'quiz', 'opinion'].includes(String(parsed.a)) ||
      !Array.isArray(parsed.q)
    ) {
      return null;
    }
    return {
      id: parsed.i,
      code: parsed.c,
      title: parsed.t,
      presenter: typeof parsed.p === 'string' ? parsed.p : '',
      activityType: parsed.a as ActivityType,
      createdAt: typeof parsed.ts === 'number' ? parsed.ts : Date.now(),
      status: 'active',
      confirmed: true,
      questions: parsed.q.map((item) => ({
        id: String(item.i),
        kind: item.k,
        prompt: String(item.p ?? ''),
        ...(item.m ? { allowMultiple: true } : {}),
        ...(item.co ? { correctOptionId: item.co } : {}),
        ...(item.ex ? { explanation: item.ex } : {}),
        ...(item.ph ? { placeholder: item.ph } : {}),
        options: Array.isArray(item.o)
          ? item.o.map((opt) => ({ id: String(opt.i), text: String(opt.t) }))
          : [],
      })),
    };
  } catch {
    return null;
  }
}

export function parseAttendeeRouteFromUrl(): {
  sessionQuery: string | null;
  fallbackSession: Session | null;
} {
  if (typeof window === 'undefined') {
    return { sessionQuery: null, fallbackSession: null };
  }
  const params = new URLSearchParams(window.location.search);
  let sessionQuery = params.get('session') || params.get('code');

  if (!sessionQuery) {
    const pathMatch = window.location.pathname.match(/^\/join\/([^/?#]+)/i);
    if (pathMatch && pathMatch[1]) {
      sessionQuery = decodeURIComponent(pathMatch[1]);
    }
  }

  const encoded = params.get('d');
  const fallbackSession = encoded ? decodeSessionPayload(encoded) : null;
  if (!sessionQuery && fallbackSession) {
    sessionQuery = fallbackSession.code || fallbackSession.id;
  }

  return { sessionQuery, fallbackSession };
}

export function getJoinUrl(sessionOrCode: Session | string): string {
  const code = typeof sessionOrCode === 'string' ? sessionOrCode : sessionOrCode.code;
  const encoded = typeof sessionOrCode === 'string' ? '' : encodeSessionPayload(sessionOrCode);
  const path = encoded
    ? `/?session=${encodeURIComponent(code)}&d=${encodeURIComponent(encoded)}`
    : `/?session=${encodeURIComponent(code)}`;

  if (typeof window === 'undefined') {
    return path;
  }
  return `${window.location.origin}${path}`;
}

export function createDefaultQuestionsForType(
  activityType: ActivityType
): SessionQuestion[] {
  if (activityType === 'poll') {
    return [
      {
        id: generateId('q'),
        kind: 'mcq',
        prompt: 'Rate the session',
        allowMultiple: false,
        options: [
          { id: 'rate_excellent', text: '🤩 Excellent' },
          { id: 'rate_very_good', text: '😊 Very good' },
          { id: 'rate_good', text: '🙂 Good' },
          { id: 'rate_poor', text: '😕 Poor' },
          { id: 'rate_too_bad', text: '😞 Too bad' },
        ],
      },
    ];
  }

  if (activityType === 'quiz') {
    return [
      {
        id: generateId('q'),
        kind: 'yes_no',
        prompt: 'Is a 4.5:1 contrast ratio the minimum WCAG AA standard for normal body text?',
        options: [
          { id: 'yes', text: 'Yes' },
          { id: 'no', text: 'No' },
        ],
        correctOptionId: 'yes',
        explanation: 'WCAG 2.1 Level AA specifies at least 4.5:1 contrast for standard body text.',
      },
      {
        id: generateId('q'),
        kind: 'yes_no',
        prompt: 'Should UI components reference raw hex color values instead of semantic tokens?',
        options: [
          { id: 'yes', text: 'Yes' },
          { id: 'no', text: 'No' },
        ],
        correctOptionId: 'no',
        explanation: 'Components should reference semantic tokens so themes and states remain consistent.',
      },
    ];
  }

  // opinion: short descriptive questions only
  return [
    {
      id: generateId('q'),
      kind: 'descriptive',
      prompt: 'What was your key takeaway from today’s session?',
      options: [],
      placeholder: 'Write a short response (max 200 characters)...',
    },
    {
      id: generateId('q'),
      kind: 'descriptive',
      prompt: 'What is one thing we could improve in future sessions?',
      options: [],
      placeholder: 'Share a brief suggestion (max 200 characters)...',
    },
  ];
}

export function createBlankQuestion(
  kind: QuestionKind,
  activityType: ActivityType
): SessionQuestion {
  if (kind === 'yes_no') {
    return {
      id: generateId('q'),
      kind: 'yes_no',
      prompt: 'Enter your Yes / No question...',
      options: [
        { id: 'yes', text: 'Yes' },
        { id: 'no', text: 'No' },
      ],
      ...(activityType === 'quiz' ? { correctOptionId: 'yes', explanation: '' } : {}),
    };
  }

  if (kind === 'mcq') {
    const optA = generateId('opt');
    const optB = generateId('opt');
    const optC = generateId('opt');
    return {
      id: generateId('q'),
      kind: 'mcq',
      prompt: 'Enter your multiple-choice question...',
      options: [
        { id: optA, text: 'Option A' },
        { id: optB, text: 'Option B' },
        { id: optC, text: 'Option C' },
      ],
      allowMultiple: false,
      ...(activityType === 'quiz' ? { correctOptionId: optA, explanation: '' } : {}),
    };
  }

  return {
    id: generateId('q'),
    kind: 'descriptive',
    prompt:
      activityType === 'opinion'
        ? 'Share a brief opinion or suggestion for this session...'
        : activityType === 'quiz'
          ? 'Explain your reasoning in your own words...'
          : 'Share any additional thoughts on this topic...',
    options: [],
    placeholder:
      activityType === 'opinion'
        ? 'Write a short response (max 200 characters)...'
        : 'Write your response here...',
  };
}

function createSeedStore(): SessionPulseStore {
  return {
    sessions: [],
    submissions: [],
  };
}

export function loadStore(): SessionPulseStore {
  if (typeof window === 'undefined') {
    return createSeedStore();
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const seed = createSeedStore();
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
      return seed;
    }
    const parsed = JSON.parse(raw) as Partial<SessionPulseStore>;
    if (!Array.isArray(parsed.sessions) || !Array.isArray(parsed.submissions)) {
      const seed = createSeedStore();
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
      return seed;
    }
    return {
      sessions: parsed.sessions,
      submissions: parsed.submissions,
    };
  } catch {
    const seed = createSeedStore();
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
    } catch {
      // Ignore storage errors
    }
    return seed;
  }
}

function broadcastUpdate(): void {
  if (typeof window === 'undefined') return;
  if (typeof BroadcastChannel !== 'undefined') {
    try {
      const channel = new BroadcastChannel(CHANNEL_NAME);
      channel.postMessage({ type: 'STORE_UPDATED', timestamp: Date.now() });
      channel.close();
    } catch {
      // Ignore BroadcastChannel errors
    }
  }
}

export function cacheStoreLocally(store: SessionPulseStore): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch {
    // Ignore storage errors
  }
}

export function saveStore(store: SessionPulseStore): void {
  cacheStoreLocally(store);
  broadcastUpdate();
}

export function subscribeToStore(
  onUpdate: (nextStore: SessionPulseStore) => void
): () => void {
  if (typeof window === 'undefined') return () => {};

  const handleStorage = (event: StorageEvent) => {
    if (event.key === STORAGE_KEY || event.key === null) {
      onUpdate(loadStore());
    }
  };

  window.addEventListener('storage', handleStorage);

  let channel: BroadcastChannel | null = null;
  if (typeof BroadcastChannel !== 'undefined') {
    try {
      channel = new BroadcastChannel(CHANNEL_NAME);
      channel.onmessage = () => {
        onUpdate(loadStore());
      };
    } catch {
      channel = null;
    }
  }

  return () => {
    window.removeEventListener('storage', handleStorage);
    if (channel) {
      channel.close();
    }
  };
}

export function findSessionByIdOrCode(
  sessions: Session[],
  query: string
): Session | undefined {
  const normalized = query.trim();
  if (!normalized) return undefined;
  const upper = normalized.toUpperCase();
  return sessions.find(
    (s) => s.id === normalized || s.code.toUpperCase() === upper
  );
}

// --- Server Persistence & Real-Time SSE Sync ---

export async function fetchServerStore(): Promise<SessionPulseStore | null> {
  if (typeof window === 'undefined') return null;
  try {
    const res = await fetch('/api/store', { cache: 'no-store' });
    if (!res.ok) return null;
    const data = (await res.json()) as Partial<SessionPulseStore>;
    if (!Array.isArray(data.sessions) || !Array.isArray(data.submissions)) {
      return null;
    }
    return {
      sessions: data.sessions,
      submissions: data.submissions,
    };
  } catch {
    return null;
  }
}

export async function fetchSessionByIdOrCode(
  idOrCode: string
): Promise<Session | undefined> {
  const cleaned = idOrCode.trim();
  if (!cleaned || typeof window === 'undefined') return undefined;
  try {
    const res = await fetch(`/api/sessions/${encodeURIComponent(cleaned)}`, {
      cache: 'no-store',
    });
    if (!res.ok) return undefined;
    const data = (await res.json()) as { session?: Session };
    return data.session;
  } catch {
    return undefined;
  }
}

export async function apiCreateSession(session: Session): Promise<void> {
  if (typeof window === 'undefined') return;
  try {
    await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session }),
    });
  } catch {
    // Local cache remains available if network is transiently offline
  }
}

const pendingSessionUpdates = new Map<string, ReturnType<typeof setTimeout>>();

export async function apiUpdateSession(
  session: Session,
  immediate = false
): Promise<void> {
  if (typeof window === 'undefined') return;

  const existingTimer = pendingSessionUpdates.get(session.id);
  if (existingTimer) {
    clearTimeout(existingTimer);
    pendingSessionUpdates.delete(session.id);
  }

  const sendUpdate = async () => {
    try {
      await fetch(`/api/sessions/${encodeURIComponent(session.id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session }),
      });
    } catch {
      // Ignore transient network errors
    }
  };

  if (immediate || session.confirmed || session.status === 'ended') {
    await sendUpdate();
    return;
  }

  const timer = setTimeout(() => {
    pendingSessionUpdates.delete(session.id);
    void sendUpdate();
  }, 150);
  pendingSessionUpdates.set(session.id, timer);
}

export async function apiDeleteSession(sessionId: string): Promise<void> {
  if (typeof window === 'undefined') return;
  const existingTimer = pendingSessionUpdates.get(sessionId);
  if (existingTimer) {
    clearTimeout(existingTimer);
    pendingSessionUpdates.delete(sessionId);
  }
  try {
    await fetch(`/api/sessions/${encodeURIComponent(sessionId)}`, {
      method: 'DELETE',
    });
  } catch {
    // Ignore transient network errors
  }
}

export interface SubmitResponseResult {
  ok: boolean;
  alreadySubmitted?: boolean;
  error?: string;
}

export async function apiSubmitResponse(
  submission: AttendeeSubmission
): Promise<SubmitResponseResult> {
  if (typeof window === 'undefined') return { ok: false };
  try {
    const res = await fetch('/api/submissions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ submission }),
    });
    if (res.status === 409) {
      const data = (await res.json().catch(() => ({}))) as {
        alreadySubmitted?: boolean;
        error?: string;
      };
      return {
        ok: false,
        alreadySubmitted: Boolean(data.alreadySubmitted),
        error: data.error || 'Submission rejected',
      };
    }
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      return { ok: false, error: data.error || 'Failed to submit response' };
    }
    return { ok: true };
  } catch {
    return { ok: false, error: 'Network error while submitting response' };
  }
}

const PARTICIPANT_TOKEN_KEY = 'sessionpulse_participant_v1';
const SUBMITTED_SESSIONS_KEY = 'sessionpulse_submitted_sessions_v1';

export function getOrCreateParticipantToken(): string {
  if (typeof window === 'undefined') return generateId('usr');
  try {
    const existing = window.localStorage.getItem(PARTICIPANT_TOKEN_KEY);
    if (existing && existing.trim().length > 0) {
      return existing;
    }
    const created =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? `usr_${crypto.randomUUID()}`
        : generateId('usr');
    window.localStorage.setItem(PARTICIPANT_TOKEN_KEY, created);
    return created;
  } catch {
    return generateId('usr');
  }
}

interface LocalSubmissionRecord {
  submittedAt: number;
  quizScore?: { score: number; total: number };
}

function loadSubmittedMap(): Record<string, LocalSubmissionRecord> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(SUBMITTED_SESSIONS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, LocalSubmissionRecord>;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function getLocalSubmissionRecord(
  sessionId: string
): LocalSubmissionRecord | null {
  const map = loadSubmittedMap();
  return map[sessionId] ?? null;
}

export function hasSubmittedSessionLocally(sessionId: string): boolean {
  return getLocalSubmissionRecord(sessionId) !== null;
}

export function markSessionSubmittedLocally(
  sessionId: string,
  quizScore?: { score: number; total: number }
): void {
  if (typeof window === 'undefined') return;
  try {
    const map = loadSubmittedMap();
    map[sessionId] = {
      submittedAt: Date.now(),
      ...(quizScore ? { quizScore } : {}),
    };
    window.localStorage.setItem(SUBMITTED_SESSIONS_KEY, JSON.stringify(map));
  } catch {
    // Ignore storage errors
  }
}

export async function checkServerSubmissionStatus(
  sessionId: string,
  participantToken: string
): Promise<{
  alreadySubmitted: boolean;
  quizScore?: { score: number; total: number };
}> {
  if (typeof window === 'undefined' || !sessionId || !participantToken) {
    return { alreadySubmitted: false };
  }
  try {
    const url = `/api/submissions/status?sessionId=${encodeURIComponent(
      sessionId
    )}&participantToken=${encodeURIComponent(participantToken)}`;
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) return { alreadySubmitted: false };
    const data = (await res.json()) as {
      alreadySubmitted?: boolean;
      quizScore?: { score: number; total: number };
    };
    return {
      alreadySubmitted: Boolean(data.alreadySubmitted),
      quizScore: data.quizScore,
    };
  } catch {
    return { alreadySubmitted: false };
  }
}

export function apiResetSessionResponses(
  sessionId: string
): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve();
  return fetch(
    `/api/sessions/${encodeURIComponent(sessionId)}/submissions`,
    { method: 'DELETE' }
  )
    .then(() => undefined)
    .catch(() => undefined);
}

export function subscribeToServerEvents(onUpdate: () => void): () => void {
  if (typeof window === 'undefined') {
    return () => {};
  }

  let source: EventSource | null = null;
  if (typeof EventSource !== 'undefined') {
    source = new EventSource('/api/events');
    source.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data) as { type?: string };
        if (parsed.type === 'store_updated') {
          onUpdate();
        }
      } catch {
        // Ignore keep-alive or malformed messages
      }
    };
  }

  const unsubscribeSupabase = subscribeSupabaseClientRealtime(onUpdate);

  return () => {
    if (source) {
      source.close();
    }
    unsubscribeSupabase();
  };
}

export function exportSessionSubmissionsCSV(
  session: Session,
  submissions: AttendeeSubmission[]
): string {
  const headers = [
    'Submission ID',
    'Submitted At',
    'Session Title',
    'Session Code',
    'Activity Type',
    ...session.questions.map((q, i) => `Q${i + 1}: ${q.prompt}`),
    ...(session.activityType === 'quiz' ? ['Quiz Score'] : []),
  ];

  const escapeCsv = (val: string) => `"${val.replace(/"/g, '""')}"`;

  const rows = submissions.map((sub) => {
    const answerCells = session.questions.map((q) => {
      const raw = sub.answers[q.id];
      if (raw === undefined) return '';
      if (q.kind === 'descriptive') {
        return typeof raw === 'string' ? raw : '';
      }
      if (Array.isArray(raw)) {
        return raw
          .map((oid) => q.options.find((o) => o.id === oid)?.text ?? oid)
          .join(' | ');
      }
      return q.options.find((o) => o.id === raw)?.text ?? raw;
    });

    const base = [
      sub.id,
      new Date(sub.submittedAt).toISOString(),
      session.title,
      session.code,
      session.activityType.toUpperCase(),
      ...answerCells,
    ];

    if (session.activityType === 'quiz') {
      base.push(
        sub.quizScore ? `${sub.quizScore.score}/${sub.quizScore.total}` : ''
      );
    }

    return base;
  });

  return [headers, ...rows]
    .map((r) => r.map(escapeCsv).join(','))
    .join('\n');
}
