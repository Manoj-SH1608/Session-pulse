export type ActivityType = 'poll' | 'quiz' | 'opinion';

export type QuestionKind = 'yes_no' | 'mcq' | 'descriptive';

export interface QuestionOption {
  id: string;
  text: string;
}

export interface SessionQuestion {
  id: string;
  kind: QuestionKind;
  prompt: string;
  options: QuestionOption[];
  allowMultiple?: boolean;
  correctOptionId?: string;
  explanation?: string;
  placeholder?: string;
}

export type SessionStatus = 'active' | 'ended';

export interface Session {
  id: string;
  code: string;
  title: string;
  presenter: string;
  activityType: ActivityType;
  createdAt: number;
  status: SessionStatus;
  confirmed: boolean;
  questions: SessionQuestion[];
}

export interface AttendeeSubmission {
  id: string;
  sessionId: string;
  submittedAt: number;
  participantToken?: string;
  /**
   * For `yes_no` and single-select `mcq`: optionId (string).
   * For multi-select `mcq`: array of optionIds (string[]).
   * For `descriptive`: free-text answer (string).
   */
  answers: Record<string, string | string[]>;
  quizScore?: {
    score: number;
    total: number;
  };
}

export interface SessionPulseStore {
  sessions: Session[];
  submissions: AttendeeSubmission[];
}
