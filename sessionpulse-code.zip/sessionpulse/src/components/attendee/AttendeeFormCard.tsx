import { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Circle,
  ExternalLink,
  Loader2,
  RotateCcw,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type {
  AttendeeSubmission,
  Session,
  SessionQuestion,
} from '../../types/session';
import {
  checkServerSubmissionStatus,
  generateId,
  getLocalSubmissionRecord,
  getOrCreateParticipantToken,
  markSessionSubmittedLocally,
  type SubmitResponseResult,
} from '../../lib/storage';

const GOOGLE_HOME_URL = 'https://www.google.com';
const REDIRECT_SECONDS = 15;

interface AttendeeFormCardProps {
  session: Session;
  previewMode?: boolean;
  onSubmit?: (
    submission: AttendeeSubmission
  ) => Promise<SubmitResponseResult> | SubmitResponseResult | void;
}

function redirectToGoogleHome(): void {
  if (typeof window === 'undefined') return;
  try {
    if (window.top && window.top !== window.self) {
      window.top.location.href = GOOGLE_HOME_URL;
      return;
    }
  } catch {
    // Fallback to current frame navigation if cross-origin top access is restricted
  }
  window.location.href = GOOGLE_HOME_URL;
}

export function AttendeeFormCard({
  session,
  previewMode = false,
  onSubmit,
}: AttendeeFormCardProps) {
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [submitted, setSubmitted] = useState(false);
  const [thankYouActive, setThankYouActive] = useState(false);
  const [alreadyRecorded, setAlreadyRecorded] = useState(false);
  const [checkingExisting, setCheckingExisting] = useState(!previewMode);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(REDIRECT_SECONDS);
  const [quizResult, setQuizResult] = useState<{ score: number; total: number } | null>(
    null
  );
  const [validationError, setValidationError] = useState('');

  // Enforce single survey per user per session (local + server check)
  useEffect(() => {
    if (previewMode) {
      setCheckingExisting(false);
      setAlreadyRecorded(false);
      return;
    }

    let cancelled = false;
    const localRecord = getLocalSubmissionRecord(session.id);
    if (localRecord) {
      setAlreadyRecorded(true);
      if (localRecord.quizScore) {
        setQuizResult(localRecord.quizScore);
      }
      setCheckingExisting(false);
      return;
    }

    const token = getOrCreateParticipantToken();
    setCheckingExisting(true);
    void checkServerSubmissionStatus(session.id, token).then((status) => {
      if (cancelled) return;
      if (status.alreadySubmitted) {
        markSessionSubmittedLocally(session.id, status.quizScore);
        setAlreadyRecorded(true);
        if (status.quizScore) {
          setQuizResult(status.quizScore);
        }
      }
      setCheckingExisting(false);
    });

    return () => {
      cancelled = true;
    };
  }, [session.id, previewMode]);

  // 15-second countdown & automatic redirect to Google homepage after submission
  useEffect(() => {
    if (!thankYouActive || previewMode) return;

    if (secondsLeft <= 0) {
      redirectToGoogleHome();
      return;
    }

    const timer = setTimeout(() => {
      setSecondsLeft((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [thankYouActive, previewMode, secondsLeft]);

  const activityLabel =
    session.activityType === 'poll'
      ? 'Anonymous Poll'
      : session.activityType === 'quiz'
        ? 'Knowledge Quiz'
        : 'Session Opinion';

  const accentBar =
    session.activityType === 'poll'
      ? 'from-sky-500 to-blue-600'
      : session.activityType === 'quiz'
        ? 'from-emerald-500 to-teal-600'
        : 'from-amber-500 to-orange-600';

  const setSingleAnswer = (questionId: string, optionId: string) => {
    if (submitted || isSubmitting) return;
    if (session.activityType === 'quiz') {
      const q = session.questions.find((item) => item.id === questionId);
      if (q?.correctOptionId && answers[questionId]) {
        return;
      }
    }
    setValidationError('');
    setAnswers((prev) => ({ ...prev, [questionId]: optionId }));
  };

  const toggleMultiAnswer = (questionId: string, optionId: string) => {
    if (submitted || isSubmitting) return;
    setValidationError('');
    setAnswers((prev) => {
      const current = Array.isArray(prev[questionId])
        ? (prev[questionId] as string[])
        : [];
      const next = current.includes(optionId)
        ? current.filter((id) => id !== optionId)
        : [...current, optionId];
      return { ...prev, [questionId]: next };
    });
  };

  const setDescriptiveAnswer = (questionId: string, text: string) => {
    if (submitted || isSubmitting) return;
    setValidationError('');
    setAnswers((prev) => ({ ...prev, [questionId]: text }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (session.questions.length === 0 || isSubmitting) return;

    for (let i = 0; i < session.questions.length; i += 1) {
      const q = session.questions[i];
      const val = answers[q.id];
      if (q.kind === 'yes_no' || (q.kind === 'mcq' && !q.allowMultiple)) {
        if (!val || typeof val !== 'string') {
          setValidationError(`Please answer question ${i + 1} before submitting.`);
          return;
        }
      } else if (q.kind === 'mcq' && q.allowMultiple) {
        if (!Array.isArray(val) || val.length === 0) {
          setValidationError(
            `Please select at least one choice for question ${i + 1}.`
          );
          return;
        }
      } else if (q.kind === 'descriptive') {
        if (typeof val !== 'string' || !val.trim()) {
          setValidationError(`Please enter your response for question ${i + 1}.`);
          return;
        }
      }
    }

    let computedQuizScore: { score: number; total: number } | undefined;
    if (session.activityType === 'quiz') {
      const gradable = session.questions.filter(
        (q) => q.kind === 'yes_no' || (q.kind === 'mcq' && !q.allowMultiple)
      );
      if (gradable.length > 0) {
        let score = 0;
        for (const q of gradable) {
          if (answers[q.id] === q.correctOptionId) {
            score += 1;
          }
        }
        computedQuizScore = { score, total: gradable.length };
      }
    }

    if (previewMode) {
      if (computedQuizScore) {
        setQuizResult(computedQuizScore);
      }
      setSubmitted(true);
      return;
    }

    setIsSubmitting(true);
    setValidationError('');
    const participantToken = getOrCreateParticipantToken();
    const submission: AttendeeSubmission = {
      id: generateId('sub'),
      sessionId: session.id,
      submittedAt: Date.now(),
      participantToken,
      answers,
      ...(computedQuizScore ? { quizScore: computedQuizScore } : {}),
    };

    const result = onSubmit ? await onSubmit(submission) : { ok: true };
    setIsSubmitting(false);

    if (result && result.alreadySubmitted) {
      markSessionSubmittedLocally(session.id, computedQuizScore);
      if (computedQuizScore) setQuizResult(computedQuizScore);
      setAlreadyRecorded(true);
      return;
    }

    if (result && !result.ok) {
      setValidationError(
        result.error || 'Could not record your response. Please try again.'
      );
      return;
    }

    markSessionSubmittedLocally(session.id, computedQuizScore);
    if (computedQuizScore) {
      setQuizResult(computedQuizScore);
    }
    setSubmitted(true);
    setSecondsLeft(REDIRECT_SECONDS);
    setThankYouActive(true);
  };

  const handleResetPreview = () => {
    if (!previewMode) return;
    setAnswers({});
    setSubmitted(false);
    setQuizResult(null);
    setValidationError('');
  };

  if (!previewMode && checkingExisting) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-3 shadow-sm">
        <Loader2 className="w-6 h-6 text-blue-600 animate-spin mx-auto" />
        <p className="text-sm font-medium text-slate-700">
          Preparing your session survey...
        </p>
      </div>
    );
  }

  // Dedicated Thank You Page with 15-second automatic redirect to Google Home Page
  if (!previewMode && thankYouActive) {
    const progressPct = Math.max(
      0,
      Math.min(100, ((REDIRECT_SECONDS - secondsLeft) / REDIRECT_SECONDS) * 100)
    );

    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm"
      >
        <div className={`h-1.5 w-full bg-gradient-to-r ${accentBar}`} />
        <div className="p-8 sm:p-12 text-center space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center mx-auto shadow-md shadow-emerald-600/20">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 text-balance">
              Thank You!
            </h1>
            <p className="text-sm sm:text-base text-slate-600 max-w-md mx-auto">
              Your response for <span className="font-semibold text-slate-900">{session.title}</span> has been recorded anonymously.
            </p>
          </div>

          {quizResult && (
            <div className="space-y-3 max-w-md mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-50 border border-emerald-200 rounded-xl text-sm font-semibold text-emerald-800 font-mono tabular-nums">
                <span>{quizResult.score === quizResult.total ? '🏆' : '🎯'}</span>
                <span>
                  Quiz Score: {quizResult.score} / {quizResult.total}
                </span>
              </div>

              <div className="text-left space-y-2 pt-1">
                {session.questions
                  .filter(
                    (q) =>
                      (q.kind === 'yes_no' || (q.kind === 'mcq' && !q.allowMultiple)) &&
                      Boolean(q.correctOptionId)
                  )
                  .map((q, qIdx) => {
                    const picked = answers[q.id];
                    const gotRight = picked === q.correctOptionId;
                    const correctText =
                      q.options.find((o) => o.id === q.correctOptionId)?.text ?? '';
                    return (
                      <div
                        key={q.id}
                        className={`px-3.5 py-2.5 rounded-xl border text-xs flex items-center justify-between gap-3 ${
                          gotRight
                            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                            : 'bg-rose-50/70 border-rose-200 text-rose-900'
                        }`}
                      >
                        <span className="truncate font-medium">
                          Q{qIdx + 1}: {q.prompt}
                        </span>
                        <span className="shrink-0 font-semibold whitespace-nowrap">
                          {gotRight
                            ? '🎉 ✅ Correct'
                            : `❌ 😅 Wrong (${correctText})`}
                        </span>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          <div className="max-w-sm mx-auto space-y-2.5 pt-2">
            <p className="text-xs font-medium text-slate-600 tabular-nums">
              Redirecting to Google home page in{' '}
              <span className="font-mono font-bold text-blue-600">
                {secondsLeft}s
              </span>
              ...
            </p>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${progressPct}%` }}
                transition={{ duration: 0.4, ease: 'linear' }}
                className="h-full rounded-full bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600"
              />
            </div>
          </div>

          <div className="pt-2">
            <a
              href={GOOGLE_HOME_URL}
              onClick={(e) => {
                e.preventDefault();
                redirectToGoogleHome();
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 rounded-xl shadow-sm transition-colors"
            >
              <span>Go to Google Now</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </motion.div>
    );
  }

  // Duplicate submission guard: one survey per participant per session
  if (!previewMode && alreadyRecorded) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
        <div className={`h-1.5 w-full bg-gradient-to-r ${accentBar}`} />
        <div className="p-8 sm:p-10 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div className="space-y-1.5">
            <h1 className="text-xl font-bold text-slate-900 text-balance">
              Response Already Recorded
            </h1>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              You have already submitted your response for{' '}
              <span className="font-semibold text-slate-900">{session.title}</span>.
              Only one survey submission is allowed per user.
            </p>
          </div>
          {quizResult && (
            <p className="font-mono text-sm font-semibold text-emerald-700 tabular-nums">
              Recorded Quiz Score: {quizResult.score} / {quizResult.total}
            </p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
      <div className={`h-1.5 w-full bg-gradient-to-r ${accentBar}`} />
      <div className="p-5 sm:p-8 space-y-6">
        {/* Header */}
        <div className="space-y-1.5 pb-5 border-b border-slate-200">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span className="font-semibold text-blue-600">{activityLabel}</span>
            <span aria-hidden="true">·</span>
            <span>Anonymous Response</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono font-semibold text-slate-700 tabular-nums">
              {session.code}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 text-balance">
            {session.title || 'Untitled Session'}
          </h2>
          {session.presenter && (
            <p className="text-sm text-slate-500">{session.presenter}</p>
          )}
        </div>

        {/* Preview Submission Confirmation Banner */}
        {previewMode && submitted && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.2 }}
            className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900"
          >
            <div className="flex items-center gap-2.5 text-sm font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              Preview submitted! Live attendees will see a Thank You page and redirect to Google in 15s.
            </div>
            {quizResult && (
              <span className="font-mono text-sm font-bold text-emerald-800 tabular-nums">
                Score: {quizResult.score} / {quizResult.total}
              </span>
            )}
          </motion.div>
        )}

        {/* Questions Form */}
        {session.questions.length === 0 ? (
          <p className="text-sm text-slate-500 py-4">
            No questions have been added to this session yet.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="divide-y divide-slate-200">
              {session.questions.map((question, idx) => (
                <QuestionBlock
                  key={question.id}
                  index={idx}
                  question={question}
                  activityType={session.activityType}
                  value={answers[question.id]}
                  submitted={submitted}
                  onSelectSingle={(optId) => setSingleAnswer(question.id, optId)}
                  onToggleMulti={(optId) => toggleMultiAnswer(question.id, optId)}
                  onChangeText={(text) => setDescriptiveAnswer(question.id, text)}
                />
              ))}
            </div>

            {validationError && (
              <motion.p
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                role="alert"
                className="text-xs font-medium text-red-700 bg-red-50 border border-red-200 rounded-xl px-3.5 py-2.5"
              >
                {validationError}
              </motion.p>
            )}

            {previewMode && submitted ? (
              <button
                type="button"
                onClick={handleResetPreview}
                className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Preview Form
              </button>
            ) : (
              <motion.button
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.99 }}
                type="submit"
                disabled={isSubmitting}
                className={`w-full min-h-[48px] px-6 py-3 bg-gradient-to-r ${accentBar} disabled:opacity-60 text-white text-sm font-semibold rounded-xl shadow-md shadow-blue-600/15 transition-all cursor-pointer disabled:cursor-not-allowed inline-flex items-center justify-center gap-2`}
              >
                {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
                {isSubmitting
                  ? 'Recording Response...'
                  : session.activityType === 'quiz'
                    ? 'Submit Quiz Answers'
                    : session.activityType === 'poll'
                      ? 'Submit Poll Vote'
                      : 'Submit Session Opinion'}
              </motion.button>
            )}
          </form>
        )}
      </div>
    </div>
  );
}

function QuestionBlock({
  index,
  question,
  activityType,
  value,
  submitted,
  onSelectSingle,
  onToggleMulti,
  onChangeText,
}: {
  index: number;
  question: SessionQuestion;
  activityType: Session['activityType'];
  value: string | string[] | undefined;
  submitted: boolean;
  onSelectSingle: (optionId: string) => void;
  onToggleMulti: (optionId: string) => void;
  onChangeText: (text: string) => void;
}) {
  const isShortOpinion = activityType === 'opinion';
  const kindLabel =
    question.kind === 'yes_no'
      ? 'Yes / No'
      : question.kind === 'mcq'
        ? question.allowMultiple
          ? 'Multiple Choice (Select all that apply)'
          : 'Multiple Choice'
        : isShortOpinion
          ? 'Short Descriptive (max 200 chars)'
          : 'Descriptive Answer';

  const isQuiz = activityType === 'quiz';
  const textValue = typeof value === 'string' ? value : '';
  const revealQuizFeedback =
    isQuiz &&
    Boolean(question.correctOptionId) &&
    (submitted || (typeof value === 'string' && value.length > 0));
  const optionsLocked = submitted || (isQuiz && Boolean(question.correctOptionId) && typeof value === 'string' && value.length > 0);

  return (
    <div className="py-6 first:pt-0 last:pb-0 space-y-3.5">
      <div className="space-y-1">
        <span className="text-xs font-medium text-slate-500">
          Question {index + 1} · {kindLabel}
        </span>
        <p className="text-base font-semibold text-slate-900">
          {question.prompt}
        </p>
      </div>

      {question.kind === 'descriptive' ? (
        <div className="space-y-1.5">
          <textarea
            rows={isShortOpinion ? 2 : 3}
            maxLength={isShortOpinion ? 200 : undefined}
            disabled={submitted}
            value={textValue}
            onChange={(e) =>
              onChangeText(
                isShortOpinion ? e.target.value.slice(0, 200) : e.target.value
              )
            }
            placeholder={
              question.placeholder ||
              (isShortOpinion
                ? 'Write a short response (max 200 characters)...'
                : 'Write your response here...')
            }
            className="w-full px-4 py-3 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15 disabled:bg-slate-50 disabled:text-slate-700"
          />
          {isShortOpinion && (
            <div className="flex justify-end">
              <span className="text-[11px] font-mono text-slate-400 tabular-nums">
                {textValue.length}/200
              </span>
            </div>
          )}
        </div>
      ) : (
        <div
          className={
            question.kind === 'yes_no' ? 'grid grid-cols-2 gap-3' : 'space-y-2.5'
          }
        >
          {question.options.map((opt) => {
            const isPicked = Array.isArray(value)
              ? value.includes(opt.id)
              : value === opt.id;
            const isCorrect =
              isQuiz &&
              Boolean(question.correctOptionId) &&
              opt.id === question.correctOptionId;

            let styleClass =
              'border-slate-200 bg-white hover:border-blue-300 hover:bg-sky-50/40 text-slate-800';
            if (!revealQuizFeedback && !submitted && isPicked) {
              styleClass = 'border-blue-600 bg-blue-50/80 text-slate-900 shadow-xs';
            } else if (revealQuizFeedback && isCorrect) {
              styleClass = 'border-emerald-300 bg-emerald-50 text-emerald-950';
            } else if (revealQuizFeedback && isPicked && !isCorrect) {
              styleClass = 'border-rose-300 bg-rose-50 text-rose-950';
            } else if (submitted && isPicked) {
              styleClass = 'border-blue-300 bg-blue-50/50 text-slate-900';
            }

            const burstEmojis = isPicked && revealQuizFeedback
              ? isCorrect
                ? ['🎉', '✅', '🏆', '🌟']
                : ['❌', '😅', '💨']
              : [];

            return (
              <div key={opt.id} className="relative">
                {/* Generated Quiz Correct / Wrong Emojis */}
                <AnimatePresence>
                  {burstEmojis.map((em, bIdx) => (
                    <motion.span
                      key={`${opt.id}-burst-${bIdx}`}
                      aria-hidden="true"
                      initial={{ opacity: 0, y: 6, scale: 0.4 }}
                      animate={{
                        opacity: [0, 1, 1, 0],
                        y: -26 - (bIdx % 2) * 8,
                        x: (bIdx - 1.5) * 18,
                        scale: [0.6, 1.35, 1],
                        rotate: (bIdx % 2 === 0 ? 1 : -1) * 14,
                      }}
                      transition={{
                        duration: 1.15,
                        delay: bIdx * 0.06,
                        ease: [0.16, 1, 0.3, 1],
                      }}
                      style={{ right: `${18 + bIdx * 10}px` }}
                      className="pointer-events-none absolute top-1 text-lg leading-none select-none z-20"
                    >
                      {em}
                    </motion.span>
                  ))}
                </AnimatePresence>

                <motion.button
                  type="button"
                  disabled={optionsLocked}
                  whileTap={!optionsLocked ? { scale: 0.985 } : {}}
                  onClick={() =>
                    question.allowMultiple
                      ? onToggleMulti(opt.id)
                      : onSelectSingle(opt.id)
                  }
                  className={`w-full min-h-[48px] px-4 py-2.5 text-left rounded-xl border flex items-center justify-between gap-3 transition-colors ${styleClass} ${
                    optionsLocked ? 'cursor-default' : 'cursor-pointer'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {revealQuizFeedback ? (
                      isCorrect ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : isPicked ? (
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                      )
                    ) : isPicked ? (
                      <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                    )}
                    <span className="text-sm font-medium">{opt.text}</span>
                  </div>

                  {revealQuizFeedback && isCorrect && (
                    <motion.span
                      initial={{ scale: 0.7, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ type: 'spring', stiffness: 420, damping: 20 }}
                      className="text-xs font-semibold text-emerald-700 shrink-0 whitespace-nowrap"
                    >
                      {isPicked ? '🎉 ✅ Correct!' : '✅ Correct'}
                    </motion.span>
                  )}

                  {revealQuizFeedback && isPicked && !isCorrect && (
                    <motion.span
                      initial={{ scale: 0.7, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ type: 'spring', stiffness: 420, damping: 20 }}
                      className="text-xs font-semibold text-rose-700 shrink-0 whitespace-nowrap"
                    >
                      ❌ 😅 Wrong
                    </motion.span>
                  )}
                </motion.button>
              </div>
            );
          })}
        </div>
      )}

      {revealQuizFeedback && question.explanation && (
        <p className="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded-lg px-3.5 py-2.5">
          {question.explanation}
        </p>
      )}
    </div>
  );
}
