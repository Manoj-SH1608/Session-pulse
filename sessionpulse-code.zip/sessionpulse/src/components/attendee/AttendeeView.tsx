import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2 } from 'lucide-react';
import type { AttendeeSubmission, Session } from '../../types/session';
import {
  apiCreateSession,
  fetchSessionByIdOrCode,
  findSessionByIdOrCode,
  type SubmitResponseResult,
} from '../../lib/storage';
import { AttendeeFormCard } from './AttendeeFormCard';

interface AttendeeViewProps {
  sessions: Session[];
  initialSessionQuery: string | null;
  fallbackSession?: Session | null;
  onSubmitResponse: (
    submission: AttendeeSubmission
  ) => Promise<SubmitResponseResult>;
  onExitToAdmin?: () => void;
}

export function AttendeeView({
  sessions,
  initialSessionQuery,
  fallbackSession = null,
  onSubmitResponse,
  onExitToAdmin,
}: AttendeeViewProps) {
  const [selectedQuery, setSelectedQuery] = useState<string>(initialSessionQuery ?? '');
  const [remoteSession, setRemoteSession] = useState<Session | null>(null);
  const matchesFallback = Boolean(
    fallbackSession &&
      selectedQuery &&
      (fallbackSession.id === selectedQuery.trim() ||
        fallbackSession.code.toUpperCase() === selectedQuery.trim().toUpperCase())
  );
  const [isLookingUp, setIsLookingUp] = useState<boolean>(() =>
    Boolean(
      initialSessionQuery &&
        !findSessionByIdOrCode(sessions, initialSessionQuery) &&
        !fallbackSession
    )
  );
  const [lookupNotFound, setLookupNotFound] = useState(false);

  const [codeInput, setCodeInput] = useState('');
  const [codeError, setCodeError] = useState('');
  const [isJoining, setIsJoining] = useState(false);

  const localMatch = useMemo(() => {
    if (!selectedQuery) return undefined;
    return findSessionByIdOrCode(sessions, selectedQuery);
  }, [sessions, selectedQuery]);

  // Resolve scanned QR link or selected query directly against the backend server
  useEffect(() => {
    const query = selectedQuery.trim();
    if (!query) {
      setRemoteSession(null);
      setIsLookingUp(false);
      setLookupNotFound(false);
      return;
    }

    let cancelled = false;
    if (!localMatch && !matchesFallback) {
      setIsLookingUp(true);
    }
    setLookupNotFound(false);

    void fetchSessionByIdOrCode(query).then((found) => {
      if (cancelled) return;
      if (found) {
        setRemoteSession(found);
        setLookupNotFound(false);
      } else if (matchesFallback && fallbackSession) {
        setRemoteSession(fallbackSession);
        setLookupNotFound(false);
        void apiCreateSession(fallbackSession);
      } else if (!localMatch) {
        setRemoteSession(null);
        setLookupNotFound(true);
      }
      setIsLookingUp(false);
    });

    return () => {
      cancelled = true;
    };
  }, [selectedQuery, localMatch, matchesFallback, fallbackSession]);

  const activeSession =
    localMatch ??
    (remoteSession &&
    (remoteSession.id === selectedQuery.trim() ||
      remoteSession.code.toUpperCase() === selectedQuery.trim().toUpperCase())
      ? remoteSession
      : matchesFallback && fallbackSession
        ? fallbackSession
        : undefined);

  const activeSessionsList = useMemo(
    () => sessions.filter((s) => s.status === 'active'),
    [sessions]
  );

  const handleJoinByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = codeInput.replace(/\D/g, '').trim();
    if (!/^\d{6}$/.test(cleaned)) {
      setCodeError('Please enter the 6-digit numeric session code.');
      return;
    }

    const localFound = findSessionByIdOrCode(sessions, cleaned);
    if (localFound) {
      setCodeError('');
      setLookupNotFound(false);
      setSelectedQuery(localFound.code);
      return;
    }

    setIsJoining(true);
    setCodeError('');
    const serverFound = await fetchSessionByIdOrCode(cleaned);
    setIsJoining(false);

    if (!serverFound) {
      setCodeError(
        'No session matches that 6-digit code. Check the number and try again.'
      );
      return;
    }

    setRemoteSession(serverFound);
    setLookupNotFound(false);
    setSelectedQuery(serverFound.code);
  };

  return (
    <div className="min-h-screen studio-canvas flex flex-col">
      {/* Compact Sticky Header (<= 56px) */}
      <header className="sticky top-0 z-30 h-14 bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4">
        <div className="min-w-0 flex items-center gap-2.5">
          <span className="font-display text-sm font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 bg-clip-text text-transparent whitespace-nowrap shrink-0">
            SessionPulse
          </span>
          {activeSession && (
            <>
              <span className="text-slate-300" aria-hidden="true">
                /
              </span>
              <span className="text-sm font-medium text-slate-700 truncate">
                {activeSession.title}
              </span>
            </>
          )}
        </div>

        {onExitToAdmin ? (
          <button
            type="button"
            onClick={onExitToAdmin}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 min-h-[44px] px-2.5 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Admin
          </button>
        ) : (
          <span className="text-xs font-medium text-slate-500 whitespace-nowrap shrink-0">
            Anonymous Survey
          </span>
        )}
      </header>

      {isLookingUp && !activeSession ? (
        <main className="flex-1 flex items-center justify-center p-4 sm:p-8">
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-3 shadow-xs">
            <Loader2 className="w-6 h-6 text-blue-600 animate-spin mx-auto" />
            <p className="text-sm font-medium text-slate-800">
              Loading session...
            </p>
            <p className="text-xs text-slate-500">
              Connecting to live session #{selectedQuery}
            </p>
          </div>
        </main>
      ) : !activeSession ? (
        <main className="flex-1 flex items-center justify-center p-4 sm:p-8">
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
            <div>
              <h1 className="text-xl font-bold text-slate-900 text-balance">
                Join a Live Session
              </h1>
              <p className="text-sm text-slate-500 mt-1">
                Enter the 6-digit numeric session code shown next to the QR code. Participation is completely anonymous.
              </p>
            </div>

            {lookupNotFound && selectedQuery && (
              <div className="p-3.5 text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl">
                Session <span className="font-mono font-semibold">{selectedQuery}</span> could not be found. Enter a valid 6-digit code or select an active session below.
              </div>
            )}

            <form onSubmit={handleJoinByCode} className="space-y-4">
              <div>
                <label
                  htmlFor="join-code-input"
                  className="block text-xs font-medium text-slate-700 mb-1.5"
                >
                  6-Digit Numeric Join Code
                </label>
                <input
                  id="join-code-input"
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="one-time-code"
                  value={codeInput}
                  onChange={(e) => {
                    const digitsOnly = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setCodeInput(digitsOnly);
                    setCodeError('');
                  }}
                  placeholder="e.g. 482910"
                  maxLength={6}
                  className="w-full h-12 px-4 text-lg font-mono font-semibold tracking-[0.25em] text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15 tabular-nums"
                />
                {codeError && (
                  <p className="text-xs text-red-600 mt-1.5">{codeError}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={isJoining}
                className="w-full h-12 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-medium rounded-xl transition-colors cursor-pointer disabled:cursor-not-allowed inline-flex items-center justify-center gap-2"
              >
                {isJoining && <Loader2 className="w-4 h-4 animate-spin" />}
                {isJoining ? 'Joining Session...' : 'Join Session'}
              </button>
            </form>

            {activeSessionsList.length > 0 && (
              <div className="pt-5 border-t border-slate-200 space-y-2.5">
                <span className="block text-xs font-medium text-slate-500">
                  Live Sessions Available Now
                </span>
                <div className="space-y-2">
                  {activeSessionsList.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => {
                        setCodeError('');
                        setSelectedQuery(s.code);
                      }}
                      className="w-full min-h-[48px] px-4 py-2.5 text-left bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-between gap-3 transition-colors cursor-pointer"
                    >
                      <span className="text-sm font-medium text-slate-900 truncate">
                        {s.title}
                      </span>
                      <span className="text-xs font-mono font-semibold text-blue-600 shrink-0 tabular-nums">
                        {s.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </main>
      ) : (
        <main className="flex-1 w-full max-w-3xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
          {activeSession.status === 'ended' ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-2">
              <h1 className="text-lg font-semibold text-slate-900">
                This session has ended
              </h1>
              <p className="text-sm text-slate-500 max-w-md mx-auto">
                Thank you for participating. The host has closed responses for this session.
              </p>
            </div>
          ) : (
            <AttendeeFormCard
              key={activeSession.id}
              session={activeSession}
              previewMode={false}
              onSubmit={onSubmitResponse}
            />
          )}
        </main>
      )}
    </div>
  );
}
