import { useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  BarChart3,
  CheckCircle2,
  Circle,
  Eye,
  HelpCircle,
  MessageSquare,
  Play,
  Plus,
  QrCode,
  Trash2,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type {
  ActivityType,
  QuestionKind,
  Session,
  SessionQuestion,
} from '../../types/session';
import {
  createBlankQuestion,
  createDefaultQuestionsForType,
  generateId,
  generateSessionCode,
} from '../../lib/storage';
import { AttendeeFormCard } from '../attendee/AttendeeFormCard';
import { QrSharePanel } from './QrSharePanel';

export type BuilderStep = 'setup' | 'questions' | 'preview' | 'qr';

interface SessionBuilderWizardProps {
  session: Session | null;
  step: BuilderStep;
  existingCodes?: string[];
  submissionCount: number;
  onStepChange: (step: BuilderStep) => void;
  onCreateSession: (session: Session) => void;
  onUpdateSession: (session: Session, immediate?: boolean) => void;
  onReopenSession?: (sessionId: string) => void;
  onGoToResults: () => void;
  onPreviewAttendeeFullScreen: () => void;
}

const ACTIVITY_CHOICES: {
  type: ActivityType;
  title: string;
  description: string;
  gradientClass: string;
  hoverBorderClass: string;
  ctaTextClass: string;
  topBarClass: string;
}[] = [
  {
    type: 'poll',
    title: 'Poll',
    description: 'Gather instant opinions and live votes from session attendees.',
    gradientClass: 'from-sky-500 to-blue-600 shadow-blue-500/25',
    hoverBorderClass: 'hover:border-blue-400',
    ctaTextClass: 'text-blue-600',
    topBarClass: 'from-sky-400 to-blue-600',
  },
  {
    type: 'quiz',
    title: 'Quiz',
    description: 'Test session comprehension with graded Yes/No, MCQ, and open answers.',
    gradientClass: 'from-emerald-500 to-teal-600 shadow-emerald-500/25',
    hoverBorderClass: 'hover:border-emerald-400',
    ctaTextClass: 'text-emerald-700',
    topBarClass: 'from-emerald-400 to-teal-600',
  },
  {
    type: 'opinion',
    title: 'Opinion',
    description: 'Collect brief, short descriptive feedback and takeaways from attendees.',
    gradientClass: 'from-amber-500 to-orange-600 shadow-orange-500/25',
    hoverBorderClass: 'hover:border-orange-400',
    ctaTextClass: 'text-orange-600',
    topBarClass: 'from-amber-400 to-orange-600',
  },
];

export function SessionBuilderWizard({
  session,
  step,
  existingCodes = [],
  submissionCount,
  onStepChange,
  onCreateSession,
  onUpdateSession,
  onReopenSession,
  onGoToResults,
  onPreviewAttendeeFullScreen,
}: SessionBuilderWizardProps) {
  const [draftTitle, setDraftTitle] = useState('');
  const [draftPresenter, setDraftPresenter] = useState('');
  const [detailsError, setDetailsError] = useState('');
  const titleInputRef = useRef<HTMLInputElement | null>(null);
  const presenterInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (step === 'setup' && !session) {
      setDraftTitle('');
      setDraftPresenter('');
      setDetailsError('');
    } else if (step === 'setup' && session) {
      setDraftTitle(session.title);
      setDraftPresenter(session.presenter);
      setDetailsError('');
    }
  }, [step, session]);

  const isDetailsReady = Boolean(draftTitle.trim() && draftPresenter.trim());

  const handleSelectActivityType = (type: ActivityType) => {
    const cleanTitle = draftTitle.trim();
    const cleanPresenter = draftPresenter.trim();

    if (!cleanTitle) {
      setDetailsError('Please enter a Session Title before choosing an activity type.');
      titleInputRef.current?.focus();
      return;
    }
    if (!cleanPresenter) {
      setDetailsError('Please enter the Presenter / Track / Room before choosing an activity type.');
      presenterInputRef.current?.focus();
      return;
    }

    setDetailsError('');

    if (!session) {
      const created: Session = {
        id: generateId('ses'),
        code: generateSessionCode(existingCodes),
        title: cleanTitle,
        presenter: cleanPresenter,
        activityType: type,
        createdAt: Date.now(),
        status: 'active',
        confirmed: false,
        questions: createDefaultQuestionsForType(type),
      };
      onCreateSession(created);
      onStepChange('questions');
      return;
    }

    const updated: Session = {
      ...session,
      title: cleanTitle,
      presenter: cleanPresenter,
      activityType: type,
      confirmed: false,
      questions:
        session.activityType === type && session.questions.length > 0
          ? session.questions
          : createDefaultQuestionsForType(type),
    };
    onUpdateSession(updated);
    onStepChange('questions');
  };

  const steps: { id: BuilderStep; label: string; number: string }[] = [
    { id: 'setup', label: 'Session & Type', number: '01' },
    { id: 'questions', label: 'Questions', number: '02' },
    { id: 'preview', label: 'Confirm & Preview', number: '03' },
    { id: 'qr', label: 'QR Code', number: '04' },
  ];

  const activeIdx = steps.findIndex((s) => s.id === step);

  return (
    <div className="space-y-6">
      {/* Guided Stepper Bar */}
      <nav
        aria-label="Session builder progress"
        className="bg-white border border-slate-200 rounded-2xl p-2.5 grid grid-cols-2 sm:grid-cols-4 gap-2.5 shadow-xs"
      >
        {steps.map((item, idx) => {
          const isCurrent = item.id === step;
          const canNavigate =
            item.id === 'setup' ||
            (session !== null &&
              (item.id !== 'qr' || session.confirmed || step === 'qr'));

          return (
            <button
              key={item.id}
              type="button"
              disabled={!canNavigate}
              onClick={() => canNavigate && onStepChange(item.id)}
              className={`relative px-3.5 py-2.5 rounded-xl text-left flex items-center gap-2.5 transition-[transform,color,background-color] duration-200 ease-in-out whitespace-nowrap z-10 ${
                isCurrent
                  ? 'text-white hover:scale-110'
                  : canNavigate
                    ? 'text-slate-700 hover:bg-slate-100 hover:scale-110 cursor-pointer'
                    : 'text-slate-400 cursor-not-allowed'
              }`}
            >
              {isCurrent && (
                <motion.span
                  layoutId="builder-step-pill"
                  transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                  className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 rounded-xl -z-10 shadow-sm shadow-blue-600/20"
                />
              )}
              <span
                className={`font-mono text-xs font-semibold tabular-nums ${
                  isCurrent
                    ? 'text-sky-200'
                    : idx < activeIdx
                      ? 'text-emerald-600'
                      : 'text-slate-400'
                }`}
              >
                {item.number}
              </span>
              <span className="text-xs font-medium truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <AnimatePresence mode="wait">
        {/* Step 1: Mandatory Session Details & Select Poll / Quiz / Opinion */}
        {step === 'setup' && (
          <motion.div
            key="step-setup"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
            {session && session.status === 'ended' && onReopenSession && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl px-5 py-4 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <p className="text-sm font-semibold text-amber-950">
                    This activity has ended
                  </p>
                  <p className="text-xs text-amber-800">
                    Reopen it now to resume accepting attendee responses, or update the details below first.
                  </p>
                </div>
                <motion.button
                  whileHover={{ y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  type="button"
                  onClick={() => onReopenSession(session.id)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-xl shadow-xs cursor-pointer whitespace-nowrap"
                >
                  <Play className="w-3.5 h-3.5" />
                  Reopen Activity
                </motion.button>
              </div>
            )}

            <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="h-1.5 w-full bg-gradient-to-r from-sky-500 via-indigo-500 to-violet-500" />
              <div className="p-6 space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 className="text-lg font-semibold text-slate-900 text-balance">
                      1. Enter Session Details (Required)
                    </h2>
                    <p className="text-sm text-slate-500 mt-0.5">
                      Both fields below are mandatory before selecting Poll, Quiz, or Opinion.
                    </p>
                  </div>
                  <span
                    className={`text-xs font-medium tabular-nums ${
                      isDetailsReady ? 'text-emerald-700' : 'text-amber-700'
                    }`}
                  >
                    {isDetailsReady ? 'Details complete' : 'Required fields pending'}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="wizard-session-title"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      Session Title <span className="text-red-600">*</span>
                    </label>
                    <input
                      ref={titleInputRef}
                      id="wizard-session-title"
                      type="text"
                      required
                      value={draftTitle}
                      onChange={(e) => {
                        setDraftTitle(e.target.value);
                        if (detailsError) setDetailsError('');
                      }}
                      placeholder="e.g., Q4 Architecture Workshop"
                      className="w-full h-11 px-3.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl transition-[transform,border-color,box-shadow] duration-200 ease-in-out hover:scale-[1.02] hover:border-blue-400 hover:shadow-sm focus:outline-none focus:scale-[1.02] focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="wizard-session-presenter"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      Presenter / Track / Room <span className="text-red-600">*</span>
                    </label>
                    <input
                      ref={presenterInputRef}
                      id="wizard-session-presenter"
                      type="text"
                      required
                      value={draftPresenter}
                      onChange={(e) => {
                        setDraftPresenter(e.target.value);
                        if (detailsError) setDetailsError('');
                      }}
                      placeholder="e.g., Main Stage · Morning Track"
                      className="w-full h-11 px-3.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl transition-[transform,border-color,box-shadow] duration-200 ease-in-out hover:scale-[1.02] hover:border-blue-400 hover:shadow-sm focus:outline-none focus:scale-[1.02] focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20"
                    />
                  </div>
                </div>

                {detailsError && (
                  <motion.p
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    role="alert"
                    className="text-xs font-medium text-red-700 bg-red-50 border border-red-200 rounded-xl px-4 py-2.5"
                  >
                    {detailsError}
                  </motion.p>
                )}
              </div>
            </section>

            <section className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5 shadow-xs">
              <div>
                <h2 className="text-lg font-semibold text-slate-900 text-balance">
                  2. Select Activity Type to Create
                </h2>
                <p className="text-sm text-slate-500 mt-0.5">
                  {isDetailsReady
                    ? 'Choose Poll (5-option session rating), Quiz, or Opinion (short descriptive) to launch the builder.'
                    : 'Fill in Session Title and Presenter / Track above to unlock your activity options.'}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {ACTIVITY_CHOICES.map((choice, idx) => {
                  const isSelected = session?.activityType === choice.type;
                  return (
                    <motion.button
                      key={choice.type}
                      type="button"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.22, delay: idx * 0.05 }}
                      onClick={() => handleSelectActivityType(choice.type)}
                      className={`rounded-2xl border text-left flex flex-col justify-between overflow-hidden transition-[transform,border-color,box-shadow,background-color] duration-200 ease-in-out hover:scale-105 hover:-translate-y-1 active:scale-[0.98] cursor-pointer ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/40 shadow-md shadow-blue-600/10'
                          : isDetailsReady
                            ? `border-slate-200 bg-white ${choice.hoverBorderClass} hover:shadow-lg hover:shadow-slate-900/10`
                            : 'border-slate-200 bg-slate-50/80 opacity-85 hover:opacity-100 hover:shadow-md'
                      }`}
                    >
                      <div className={`h-1.5 w-full bg-gradient-to-r ${choice.topBarClass}`} />
                      <div className="p-5 space-y-3 flex-1">
                        <div
                          className={`w-11 h-11 rounded-xl bg-gradient-to-br ${choice.gradientClass} text-white flex items-center justify-center shadow-md`}
                        >
                          {choice.type === 'poll' && <BarChart3 className="w-5 h-5" />}
                          {choice.type === 'quiz' && <HelpCircle className="w-5 h-5" />}
                          {choice.type === 'opinion' && (
                            <MessageSquare className="w-5 h-5" />
                          )}
                        </div>
                        <h3 className="text-base font-semibold text-slate-900">
                          {choice.title}
                        </h3>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {choice.description}
                        </p>
                      </div>

                      <div
                        className={`px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs font-semibold ${
                          isDetailsReady ? choice.ctaTextClass : 'text-slate-400'
                        }`}
                      >
                        <span>
                          {isDetailsReady
                            ? `Continue with ${choice.title}`
                            : 'Complete details first'}
                        </span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </section>
          </motion.div>
        )}

        {/* Step 2: Default Yes/No Questions + Add MCQ / Descriptive */}
        {step === 'questions' && session && (
          <motion.div
            key="step-questions"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          >
            <QuestionsEditorStep
              session={session}
              onUpdateSession={onUpdateSession}
              onReopenSession={onReopenSession}
              onBack={() => onStepChange('setup')}
              onNext={() => onStepChange('preview')}
            />
          </motion.div>
        )}

        {/* Step 3: Confirm Details & Attendee Preview */}
        {step === 'preview' && session && (
          <motion.div
            key="step-preview"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          >
            <ConfirmAndPreviewStep
              session={session}
              onBack={() => onStepChange('questions')}
              onConfirmGenerateQr={() => {
                onUpdateSession(
                  { ...session, status: 'active', confirmed: true },
                  true
                );
                onStepChange('qr');
              }}
            />
          </motion.div>
        )}

        {/* Step 4: Generated QR Code */}
        {step === 'qr' && session && (
          <motion.div
            key="step-qr"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-4"
          >
            <div
              className={`flex flex-wrap items-center justify-between gap-3 bg-white border rounded-2xl px-5 py-3.5 shadow-xs ${
                session.status === 'ended' ? 'border-amber-300' : 'border-emerald-200'
              }`}
            >
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <CheckCircle2
                  className={`w-4 h-4 shrink-0 ${
                    session.status === 'ended' ? 'text-amber-600' : 'text-emerald-600'
                  }`}
                />
                <span
                  className={`font-semibold ${
                    session.status === 'ended' ? 'text-amber-900' : 'text-emerald-800'
                  }`}
                >
                  {session.status === 'ended'
                    ? 'This activity has ended — reopen it so attendees can submit'
                    : 'Session confirmed and QR code is live'}
                </span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">
                  {session.questions.length} questions ready
                </span>
              </div>
              <div className="flex items-center gap-2">
                {session.status === 'ended' && onReopenSession && (
                  <button
                    type="button"
                    onClick={() => onReopenSession(session.id)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-lg cursor-pointer whitespace-nowrap"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Reopen Activity
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onStepChange('questions')}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer whitespace-nowrap"
                >
                  Edit Questions
                </button>
                <button
                  type="button"
                  onClick={onGoToResults}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 rounded-lg cursor-pointer whitespace-nowrap"
                >
                  View Live Results
                </button>
              </div>
            </div>

            <QrSharePanel
              session={session}
              responseCount={submissionCount}
              onPreviewAttendee={onPreviewAttendeeFullScreen}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function QuestionsEditorStep({
  session,
  onUpdateSession,
  onReopenSession,
  onBack,
  onNext,
}: {
  session: Session;
  onUpdateSession: (updated: Session, immediate?: boolean) => void;
  onReopenSession?: (sessionId: string) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const activityLabel =
    session.activityType === 'poll'
      ? 'Poll'
      : session.activityType === 'quiz'
        ? 'Quiz'
        : 'Session Opinion';

  const accentGradient =
    session.activityType === 'poll'
      ? 'from-sky-500 to-blue-600'
      : session.activityType === 'quiz'
        ? 'from-emerald-500 to-teal-600'
        : 'from-amber-500 to-orange-600';

  const updateQuestion = (
    questionId: string,
    updater: (prev: SessionQuestion) => SessionQuestion
  ) => {
    onUpdateSession({
      ...session,
      confirmed: false,
      questions: session.questions.map((q) => (q.id === questionId ? updater(q) : q)),
    });
  };

  const addQuestion = (kind: QuestionKind) => {
    const created = createBlankQuestion(kind, session.activityType);
    onUpdateSession({
      ...session,
      confirmed: false,
      questions: [...session.questions, created],
    });
  };

  const moveQuestion = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= session.questions.length) return;
    const next = [...session.questions];
    const [item] = next.splice(index, 1);
    next.splice(target, 0, item);
    onUpdateSession({ ...session, confirmed: false, questions: next });
  };

  const removeQuestion = (questionId: string) => {
    if (session.questions.length <= 1) return;
    onUpdateSession({
      ...session,
      confirmed: false,
      questions: session.questions.filter((q) => q.id !== questionId),
    });
  };

  return (
    <div className="space-y-6">
      {session.status === 'ended' && onReopenSession && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl px-5 py-4 flex flex-wrap items-center justify-between gap-3 shadow-xs">
          <div className="space-y-0.5">
            <p className="text-sm font-semibold text-amber-950">
              This {activityLabel.toLowerCase()} is currently ended
            </p>
            <p className="text-xs text-amber-800">
              Attendees cannot submit responses while ended. Reopen this activity now or after editing your questions.
            </p>
          </div>
          <motion.button
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            onClick={() => onReopenSession(session.id)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-xl shadow-xs cursor-pointer whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5" />
            Reopen Activity
          </motion.button>
        </div>
      )}

      {/* Editable Session Summary Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className={`h-1.5 w-full bg-gradient-to-r ${accentGradient}`} />
        <div className="p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="text-xs font-semibold text-blue-600">
                {session.activityType === 'poll'
                  ? 'Poll Builder · Default 5-Option Emoji Rating Pre-loaded'
                  : session.activityType === 'opinion'
                    ? 'Session Opinion Builder · Default Short Descriptive Questions Pre-loaded'
                    : `${activityLabel} Builder · Default Yes/No Questions Pre-loaded`}
              </span>
              <h2 className="text-lg font-semibold text-slate-900 mt-0.5">
                {session.activityType === 'poll'
                  ? 'Customize Questions & Add Yes/No or MCQ Items'
                  : session.activityType === 'opinion'
                    ? 'Customize Short Descriptive Questions'
                    : 'Customize Questions & Add MCQ or Descriptive Items'}
              </h2>
            </div>
            <button
              type="button"
              onClick={onBack}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer whitespace-nowrap"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Change Details / Type
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3 border-t border-slate-200">
            <div>
              <label
                htmlFor="edit-session-title"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Session Title <span className="text-red-600">*</span>
              </label>
              <input
                id="edit-session-title"
                type="text"
                required
                value={session.title}
                onChange={(e) =>
                  onUpdateSession({ ...session, title: e.target.value, confirmed: false })
                }
                className="w-full px-3 py-2 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg transition-[transform,border-color,box-shadow] duration-200 ease-in-out hover:scale-[1.02] hover:border-blue-400 hover:shadow-sm focus:outline-none focus:scale-[1.02] focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20"
              />
            </div>
            <div>
              <label
                htmlFor="edit-session-presenter"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Presenter / Track / Room <span className="text-red-600">*</span>
              </label>
              <input
                id="edit-session-presenter"
                type="text"
                required
                value={session.presenter}
                onChange={(e) =>
                  onUpdateSession({ ...session, presenter: e.target.value, confirmed: false })
                }
                className="w-full px-3 py-2 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg transition-[transform,border-color,box-shadow] duration-200 ease-in-out hover:scale-[1.02] hover:border-blue-400 hover:shadow-sm focus:outline-none focus:scale-[1.02] focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Question Cards */}
      <div className="space-y-4">
        <AnimatePresence initial={false}>
          {session.questions.map((question, idx) => (
            <motion.div
              key={question.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-3.5 bg-slate-50/80 border-b border-slate-200">
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <span className="font-mono font-semibold text-blue-700 tabular-nums">
                    Q{idx + 1}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-medium text-slate-800">
                    {question.kind === 'yes_no'
                      ? 'Yes / No Question'
                      : question.kind === 'mcq'
                        ? 'Multiple Choice (MCQ)'
                        : session.activityType === 'opinion'
                          ? 'Short Descriptive Answer'
                          : 'Descriptive Answer'}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => moveQuestion(idx, -1)}
                    disabled={idx === 0}
                    aria-label="Move question up"
                    className="p-1.5 text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-md disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => moveQuestion(idx, 1)}
                    disabled={idx === session.questions.length - 1}
                    aria-label="Move question down"
                    className="p-1.5 text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-md disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => removeQuestion(question.id)}
                    disabled={session.questions.length <= 1}
                    aria-label="Delete question"
                    className="p-1.5 text-slate-500 hover:text-red-600 bg-white border border-slate-200 rounded-md disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="p-5 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">
                    Question Prompt
                  </label>
                  <input
                    type="text"
                    value={question.prompt}
                    onChange={(e) =>
                      updateQuestion(question.id, (prev) => ({
                        ...prev,
                        prompt: e.target.value,
                      }))
                    }
                    placeholder="Enter your question..."
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15"
                  />
                </div>

                {question.kind === 'yes_no' && (
                  <div className="space-y-2">
                    <span className="block text-xs text-slate-500">
                      {session.activityType === 'quiz'
                        ? 'Fixed choices (Yes / No) — select the correct quiz answer:'
                        : 'Fixed choices shown to attendees: Yes / No'}
                    </span>
                    <div className="flex flex-wrap items-center gap-2.5">
                      {question.options.map((opt) => {
                        const isCorrect =
                          session.activityType === 'quiz' &&
                          question.correctOptionId === opt.id;
                        return session.activityType === 'quiz' ? (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() =>
                              updateQuestion(question.id, (prev) => ({
                                ...prev,
                                correctOptionId: opt.id,
                              }))
                            }
                            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border cursor-pointer transition-colors ${
                              isCorrect
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            {isCorrect ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Circle className="w-3.5 h-3.5 text-slate-300" />
                            )}
                            {opt.text} {isCorrect ? '(Correct Answer)' : ''}
                          </button>
                        ) : (
                          <span
                            key={opt.id}
                            className="px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
                          >
                            {opt.text}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                )}

                {question.kind === 'mcq' && (
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs font-medium text-slate-700">
                        Answer Choices ({question.options.length}/6)
                      </span>
                      {session.activityType !== 'quiz' && (
                        <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={Boolean(question.allowMultiple)}
                            onChange={(e) =>
                              updateQuestion(question.id, (prev) => ({
                                ...prev,
                                allowMultiple: e.target.checked,
                              }))
                            }
                            className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-600"
                          />
                          Allow multiple selections
                        </label>
                      )}
                    </div>

                    <div className="space-y-2">
                      {question.options.map((opt, oIdx) => {
                        const isCorrect =
                          session.activityType === 'quiz' &&
                          question.correctOptionId === opt.id;
                        return (
                          <div key={opt.id} className="flex items-center gap-2">
                            {session.activityType === 'quiz' && (
                              <button
                                type="button"
                                onClick={() =>
                                  updateQuestion(question.id, (prev) => ({
                                    ...prev,
                                    correctOptionId: opt.id,
                                  }))
                                }
                                className={`inline-flex items-center gap-1.5 px-2.5 py-2 text-xs font-medium rounded-lg border whitespace-nowrap shrink-0 cursor-pointer ${
                                  isCorrect
                                    ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                                    : 'bg-white border-slate-200 text-slate-500 hover:text-slate-800'
                                }`}
                              >
                                {isCorrect ? (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Circle className="w-3.5 h-3.5 text-slate-300" />
                                )}
                                {isCorrect ? 'Correct' : 'Mark'}
                              </button>
                            )}

                            <input
                              type="text"
                              value={opt.text}
                              onChange={(e) =>
                                updateQuestion(question.id, (prev) => ({
                                  ...prev,
                                  options: prev.options.map((o) =>
                                    o.id === opt.id ? { ...o, text: e.target.value } : o
                                  ),
                                }))
                              }
                              placeholder={`Option ${oIdx + 1}`}
                              className="flex-1 px-3 py-2 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                            />

                            <button
                              type="button"
                              disabled={question.options.length <= 2}
                              onClick={() =>
                                updateQuestion(question.id, (prev) => {
                                  const filtered = prev.options.filter(
                                    (o) => o.id !== opt.id
                                  );
                                  return {
                                    ...prev,
                                    options: filtered,
                                    correctOptionId:
                                      prev.correctOptionId === opt.id
                                        ? filtered[0]?.id
                                        : prev.correctOptionId,
                                  };
                                })
                              }
                              aria-label="Remove option"
                              className="p-2 text-slate-400 hover:text-red-600 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    {question.options.length < 6 && (
                      <button
                        type="button"
                        onClick={() =>
                          updateQuestion(question.id, (prev) => ({
                            ...prev,
                            options: [
                              ...prev.options,
                              {
                                id: generateId('opt'),
                                text: `Option ${prev.options.length + 1}`,
                              },
                            ],
                          }))
                        }
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 hover:text-blue-700 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Add MCQ Option
                      </button>
                    )}
                  </div>
                )}

                {question.kind === 'descriptive' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Attendee Answer Placeholder Hint
                    </label>
                    <input
                      type="text"
                      value={question.placeholder ?? ''}
                      onChange={(e) =>
                        updateQuestion(question.id, (prev) => ({
                          ...prev,
                          placeholder: e.target.value,
                        }))
                      }
                      placeholder="Write your response here..."
                      className="w-full px-3 py-2 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white focus:border-blue-600"
                    />
                  </div>
                )}

                {session.activityType === 'quiz' && question.kind !== 'descriptive' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Explanation (shown to attendees after quiz submission, optional)
                    </label>
                    <input
                      type="text"
                      value={question.explanation ?? ''}
                      onChange={(e) =>
                        updateQuestion(question.id, (prev) => ({
                          ...prev,
                          explanation: e.target.value,
                        }))
                      }
                      placeholder="Explain the correct answer..."
                      className="w-full px-3 py-2 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white focus:border-blue-600"
                    />
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Add More Questions Prompt Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Want to add more questions?
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {session.activityType === 'poll'
              ? 'Append Yes/No checks or multiple-choice (MCQ) questions to your poll.'
              : session.activityType === 'opinion'
                ? 'Append short descriptive opinion prompts (up to 200 characters per response).'
                : 'Append Yes/No checks, multiple-choice (MCQ) questions, or descriptive text prompts.'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {session.activityType !== 'opinion' && (
            <>
              <motion.button
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={() => addQuestion('yes_no')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-sky-700 bg-sky-50 border border-sky-200 hover:bg-sky-100 rounded-lg cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Yes / No
              </motion.button>
              <motion.button
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={() => addQuestion('mcq')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 rounded-lg cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                Add MCQ
              </motion.button>
            </>
          )}
          {session.activityType !== 'poll' && (
            <motion.button
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              onClick={() => addQuestion('descriptive')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-orange-700 bg-orange-50 border border-orange-200 hover:bg-orange-100 rounded-lg cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              {session.activityType === 'opinion'
                ? 'Add Short Descriptive'
                : 'Add Descriptive'}
            </motion.button>
          )}
        </div>
      </div>

      {/* End of Page: Confirm Details & Preview CTA */}
      <div className="flex items-center justify-between gap-4 pt-2">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl cursor-pointer whitespace-nowrap"
        >
          Back to Details
        </button>

        <motion.button
          whileHover={{ y: -1 }}
          whileTap={{ scale: 0.98 }}
          type="button"
          disabled={!session.title.trim() || !session.presenter.trim()}
          onClick={onNext}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-700 hover:via-indigo-700 hover:to-violet-700 disabled:opacity-50 rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer disabled:cursor-not-allowed whitespace-nowrap"
        >
          <Eye className="w-4 h-4" />
          Confirm Details &amp; Preview
        </motion.button>
      </div>
    </div>
  );
}

function ConfirmAndPreviewStep({
  session,
  onBack,
  onConfirmGenerateQr,
}: {
  session: Session;
  onBack: () => void;
  onConfirmGenerateQr: () => void;
}) {
  const yesNoCount = session.questions.filter((q) => q.kind === 'yes_no').length;
  const mcqCount = session.questions.filter((q) => q.kind === 'mcq').length;
  const descCount = session.questions.filter((q) => q.kind === 'descriptive').length;

  const activityLabel =
    session.activityType === 'poll'
      ? 'Poll'
      : session.activityType === 'quiz'
        ? 'Quiz'
        : 'Session Opinion';

  return (
    <div className="space-y-6">
      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="h-1.5 w-full bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-500" />
        <div className="p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <span className="text-xs font-semibold text-blue-600">
                Final Confirmation Before QR Generation
              </span>
              <h2 className="text-lg font-semibold text-slate-900 mt-0.5">
                Review Details to Be Obtained ({activityLabel})
              </h2>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={onBack}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl cursor-pointer whitespace-nowrap"
              >
                Back to Edit
              </button>
              <motion.button
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={onConfirmGenerateQr}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-700 hover:via-indigo-700 hover:to-violet-700 rounded-xl shadow-sm shadow-blue-600/20 cursor-pointer whitespace-nowrap"
              >
                <QrCode className="w-3.5 h-3.5" />
                {session.status === 'ended'
                  ? 'Reopen & Generate QR'
                  : 'Confirm & Generate QR'}
              </motion.button>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="block text-xs text-slate-500">Session Title</span>
              <span className="font-semibold text-slate-900">{session.title}</span>
            </div>
            <div>
              <span className="block text-xs text-slate-500">Presenter / Track</span>
              <span className="font-semibold text-slate-900">{session.presenter}</span>
            </div>
            <div>
              <span className="block text-xs text-slate-500">Activity Type</span>
              <span className="font-semibold text-blue-700">{activityLabel}</span>
            </div>
            <div>
              <span className="block text-xs text-slate-500">Question Breakdown</span>
              <span className="font-medium text-slate-800 tabular-nums">
                {session.activityType === 'opinion'
                  ? `${descCount} Short Descriptive`
                  : session.activityType === 'poll'
                    ? `${yesNoCount} Yes/No · ${mcqCount} MCQ`
                    : `${yesNoCount} Yes/No · ${mcqCount} MCQ · ${descCount} Descriptive`}
              </span>
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Attendee View Preview
            </h3>
            <p className="text-xs text-slate-500">
              Interactive preview of the exact form participants will see after scanning the QR code (no sign-in required).
            </p>
          </div>
          <span className="text-xs font-medium text-indigo-700">Preview Mode</span>
        </div>

        <div className="bg-gradient-to-br from-sky-50 via-indigo-50/40 to-amber-50/40 border border-slate-200 rounded-2xl p-4 sm:p-8">
          <div className="max-w-2xl mx-auto">
            <AttendeeFormCard session={session} previewMode={true} />
          </div>
        </div>
      </section>

      <div className="flex items-center justify-between gap-4 pt-2">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl cursor-pointer whitespace-nowrap"
        >
          Back to Questions
        </button>
        <motion.button
          whileHover={{ y: -1 }}
          whileTap={{ scale: 0.98 }}
          type="button"
          onClick={onConfirmGenerateQr}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-700 hover:via-indigo-700 hover:to-violet-700 rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer whitespace-nowrap"
        >
          <QrCode className="w-4 h-4" />
          {session.status === 'ended'
            ? 'Reopen Activity & Generate QR Code'
            : 'Confirm & Generate QR Code'}
        </motion.button>
      </div>
    </div>
  );
}
