import { useEffect, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  Maximize2,
  Smartphone,
  X,
} from 'lucide-react';
import type { Session } from '../../types/session';
import { apiUpdateSession, getJoinUrl } from '../../lib/storage';

interface QrSharePanelProps {
  session: Session;
  responseCount: number;
  onPreviewAttendee: () => void;
}

export function QrSharePanel({
  session,
  responseCount,
  onPreviewAttendee,
}: QrSharePanelProps) {
  const [copied, setCopied] = useState(false);
  const [projectorOpen, setProjectorOpen] = useState(false);
  const qrContainerRef = useRef<HTMLDivElement | null>(null);

  const joinUrl = getJoinUrl(session);
  const activityLabel =
    session.activityType === 'poll'
      ? 'Poll'
      : session.activityType === 'quiz'
        ? 'Quiz'
        : 'Opinion';

  useEffect(() => {
    void apiUpdateSession(session, true);
  }, [session.id, session.confirmed]);

  useEffect(() => {
    if (!projectorOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setProjectorOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [projectorOpen]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(joinUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const input = document.createElement('input');
      input.value = joinUrl;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadPng = () => {
    const svg = qrContainerRef.current?.querySelector('svg');
    if (!svg) return;

    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svg);
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const width = 720;
      const height = 860;
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        URL.revokeObjectURL(url);
        return;
      }

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);

      ctx.drawImage(img, 80, 60, 560, 560);

      ctx.fillStyle = '#0f172a';
      ctx.font = '600 28px "Plus Jakarta Sans", system-ui, sans-serif';
      ctx.textAlign = 'center';
      const titleText =
        session.title.length > 38 ? `${session.title.slice(0, 35)}...` : session.title;
      ctx.fillText(titleText, width / 2, 685);

      ctx.fillStyle = '#475569';
      ctx.font = '500 20px "DM Sans", system-ui, sans-serif';
      ctx.fillText('Scan to participate anonymously · No sign-in required', width / 2, 725);

      ctx.fillStyle = '#2563eb';
      ctx.font = '600 32px "JetBrains Mono", monospace';
      ctx.fillText(`CODE: ${session.code}`, width / 2, 785);

      const pngUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `sessionpulse-${session.code.toLowerCase()}-qr.png`;
      link.href = pngUrl;
      link.click();
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left: Scannable QR Display */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-8 flex flex-col items-center justify-center text-center">
          <div
            ref={qrContainerRef}
            className="p-5 bg-white border border-slate-200 rounded-xl"
          >
            <QRCodeSVG
              value={joinUrl}
              size={220}
              level="M"
              bgColor="#ffffff"
              fgColor="#0f172a"
            />
          </div>

          <div className="mt-5">
            <span className="text-xs font-medium text-slate-500">
              Session Join Code
            </span>
            <p className="text-2xl font-mono font-semibold tracking-widest text-slate-900 mt-1 tabular-nums">
              {session.code}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2.5 mt-6">
            <button
              type="button"
              onClick={() => setProjectorOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              Project Full-Screen
            </button>
            <button
              type="button"
              onClick={handleDownloadPng}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Download PNG
            </button>
          </div>
        </div>

        {/* Right: Link Sharing & Single-Device Demo Launch */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-slate-900 text-balance">
                Share QR Code with Session Attendees
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                Attendees scan this QR code or open the link below to fill out your {activityLabel.toLowerCase()} anonymously. Submitted responses reflect immediately in Live Results and Records.
              </p>
            </div>

            {/* Summary Metadata Line */}
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 pb-5 border-b border-slate-200">
              <span className="font-medium text-slate-900">{session.title}</span>
              <span aria-hidden="true">·</span>
              <span>{activityLabel}</span>
              <span aria-hidden="true">·</span>
              <span
                className={
                  session.status === 'active'
                    ? 'text-emerald-700 font-medium'
                    : 'text-slate-600'
                }
              >
                {session.status === 'active' ? 'Active' : 'Ended'}
              </span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums">{session.questions.length} questions</span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums">{responseCount} responses</span>
            </div>

            {/* Direct Link Box */}
            <div>
              <label
                htmlFor="attendee-join-url"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Direct Attendee Link
              </label>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  id="attendee-join-url"
                  type="text"
                  readOnly
                  value={joinUrl}
                  onFocus={(e) => e.currentTarget.select()}
                  className="flex-1 px-3.5 py-2.5 text-xs font-mono text-slate-700 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
                <button
                  type="button"
                  onClick={handleCopy}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-medium text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Link
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Single-Device Demo & Testing Launcher */}
            <div className="pt-4 border-t border-slate-200 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900">
                Single-Device Demo &amp; Live Sync Test
              </h3>
              <p className="text-xs text-slate-500">
                Open the Attendee View in a second tab or switch here to fill out the {activityLabel.toLowerCase()} and watch Live Results update automatically.
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <a
                  href={joinUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Open Attendee View in New Tab
                </a>
                <button
                  type="button"
                  onClick={onPreviewAttendee}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Smartphone className="w-3.5 h-3.5 text-blue-600" />
                  Switch to Attendee View Here
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Projector Full-Screen QR Modal */}
      {projectorOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Full-screen session QR code"
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xs flex items-center justify-center p-6"
        >
          <div className="relative w-full max-w-2xl bg-white rounded-2xl p-10 text-center shadow-2xl">
            <button
              type="button"
              onClick={() => setProjectorOpen(false)}
              aria-label="Close full-screen QR view"
              className="absolute top-5 right-5 p-2 text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <p className="text-xs font-medium text-blue-600">
              Scan to Join {activityLabel} Anonymously
            </p>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-2 text-balance">
              {session.title}
            </h2>
            {session.presenter && (
              <p className="text-sm text-slate-500 mt-1">{session.presenter}</p>
            )}

            <div className="inline-block p-6 mt-7 bg-white border border-slate-200 rounded-2xl">
              <QRCodeSVG
                value={joinUrl}
                size={300}
                level="M"
                bgColor="#ffffff"
                fgColor="#0f172a"
              />
            </div>

            <div className="mt-6">
              <p className="text-xs text-slate-500">Or enter session code</p>
              <p className="text-3xl font-mono font-bold tracking-[0.2em] text-slate-900 mt-1 tabular-nums">
                {session.code}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
