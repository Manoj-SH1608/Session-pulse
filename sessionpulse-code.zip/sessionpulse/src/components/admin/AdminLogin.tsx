import { useState } from 'react';
import { Eye, EyeOff, Lock } from 'lucide-react';
import { motion } from 'motion/react';
import { verifyAdminCredentials } from '../../lib/auth';

interface AdminLoginProps {
  onLoginSuccess: (email: string, token?: string) => void;
}

export function AdminLogin({ onLoginSuccess }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      setError('Please enter both your User ID and Password.');
      return;
    }

    setSubmitting(true);
    try {
      const ok = await verifyAdminCredentials(cleanEmail, password);
      if (!ok) {
        setError('Invalid User ID or Password. Please check your credentials and try again.');
        return;
      }

      let token: string | undefined;
      try {
        const res = await fetch('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: cleanEmail, password }),
        });
        if (res.ok) {
          const data = (await res.json()) as { token?: string };
          token = data.token;
        }
      } catch {
        // Offline fallback keeps client session active
      }

      onLoginSuccess(cleanEmail, token);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen studio-canvas flex flex-col justify-center items-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-1.5">
          <span className="font-display text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 bg-clip-text text-transparent">
            SessionPulse
          </span>
          <p className="text-sm text-slate-600">
            Admin Session Studio · Sign in to create polls, quizzes &amp; QR codes
          </p>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5">
          <div className="h-1.5 w-full bg-gradient-to-r from-sky-500 via-blue-600 to-violet-600" />
          <div className="p-6 sm:p-8 space-y-6">
            <div className="flex items-center gap-3.5 pb-4 border-b border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm shadow-blue-600/20">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <h1 className="text-base font-semibold text-slate-900">
                  Admin Portal Sign In
                </h1>
                <p className="text-xs text-slate-500">
                  Enter your administrator credentials to continue
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="admin-email"
                  className="block text-xs font-medium text-slate-700 mb-1.5"
                >
                  User ID (Email)
                </label>
                <input
                  id="admin-email"
                  type="email"
                  autoComplete="username"
                  autoFocus
                  required
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError('');
                  }}
                  placeholder="admin123@gmail.com"
                  className="w-full h-11 px-3.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 transition-shadow"
                />
              </div>

              <div>
                <label
                  htmlFor="admin-password"
                  className="block text-xs font-medium text-slate-700 mb-1.5"
                >
                  Password
                </label>
                <div className="relative">
                  <input
                    id="admin-password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    required
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError('');
                    }}
                    placeholder="Enter password"
                    className="w-full h-11 pl-3.5 pr-11 text-sm text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 transition-shadow"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {error && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  role="alert"
                  className="text-xs font-medium text-red-700 bg-red-50 border border-red-200 rounded-xl px-3.5 py-2.5"
                >
                  {error}
                </motion.p>
              )}

              <motion.button
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.99 }}
                type="submit"
                disabled={submitting}
                className="w-full h-11 px-4 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-700 hover:via-indigo-700 hover:to-violet-700 disabled:opacity-60 rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer"
              >
                {submitting ? 'Signing in...' : 'Sign In to Admin Studio'}
              </motion.button>
            </form>

            <p className="text-xs text-slate-500 pt-3 border-t border-slate-100">
              Temporary Admin ID:{' '}
              <span className="font-mono font-medium text-slate-800">
                admin123@gmail.com
              </span>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
