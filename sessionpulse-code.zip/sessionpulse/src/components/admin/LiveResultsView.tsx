import { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  Pencil,
  Play,
  Power,
  QrCode,
  RotateCcw,
  XCircle,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type {
  AttendeeSubmission,
  Session,
  SessionQuestion,
} from '../../types/session';
import { exportSessionSubmissionsCSV } from '../../lib/storage';

interface LiveResultsViewProps {
  sessions: Session[];
  selectedSession: Session | undefined;
  submissions: AttendeeSubmission[];
  onSelectSession: (sessionId: string) => void;
  onResetResponses: (sessionId: string) => void;
  onEndSession: (sessionId: string) => void;
  onReopenSession?: (sessionId: string) => void;
  onEditSession?: (sessionId: string) => void;
  onViewQr: (sessionId: string) => void;
  onGoToBuilder: () => void;
}

export function LiveResultsView({
  sessions,
  selectedSession,
  submissions,
  onSelectSession,
  onResetResponses,
  onEndSession,
  onReopenSession,
  onEditSession,
  onViewQr,
  onGoToBuilder,
}: LiveResultsViewProps) {
  const [confirmReset, setConfirmReset] = useState(false);
  const [confirmEnd, setConfirmEnd] = useState(false);

  if (!selectedSession) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="h-1.5 w-full bg-gradient-to-r from-sky-400 via-blue-500 to-violet-500" />
        <div className="p-10 text-center space-y-4">
          <div className="space-y-1.5">
            <h2 className="text-lg font-semibold text-slate-900">
              No active session running
            </h2>
            <p className="text-sm text-slate-500 max-w-md mx-auto">
              Create a Poll, Quiz, or Opinion session in the Session Builder and confirm its QR code to monitor live responses here.
            </p>
          </div>
          <motion.button
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            onClick={onGoToBuilder}
            className="inline-flex items-center justify-center px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-700 hover:via-indigo-700 hover:to-violet-700 rounded-xl shadow-sm shadow-blue-600/20 transition-all cursor-pointer"
          >
            Open Session Builder
          </motion.button>
        </div>
      </div>
    );
  }

  const sessionSubmissions = submissions.filter(
    (s) => s.sessionId === selectedSession.id
  );

  const quizSubs = sessionSubmissions.filter((s) => Boolean(s.quizScore));
  const avgQuizPct =
    quizSubs.length > 0
      ? Math.round(
          (quizSubs.reduce(
            (sum, s) =>
              sum +
              (s.quizScore && s.quizScore.total > 0
                ? s.quizScore.score / s.quizScore.total
                : 0),
            0
          ) /
            quizSubs.length) *
            100
        )
      : null;

  const activityLabel =
    selectedSession.activityType === 'poll'
      ? 'Poll'
      : selectedSession.activityType === 'quiz'
        ? 'Quiz'
        : 'Opinion';

  const handleExportCsv = () => {
    const csv = exportSessionSubmissionsCSV(selectedSession, sessionSubmissions);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sessionpulse-${selectedSession.code.toLowerCase()}-results.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="font-medium text-slate-900">{selectedSession.title}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-700 tabular-nums">
              {selectedSession.code}
            </span>
            <span aria-hidden="true">·</span>
            <span
              className={
                selectedSession.status === 'active'
                  ? 'font-semibold text-emerald-700'
                  : 'font-medium text-slate-500'
              }
            >
              {selectedSession.status === 'active' ? 'Active' : 'Ended'}
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">Live Results</h2>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {sessions.length > 1 && (
            <select
              aria-label="Select session to inspect"
              value={selectedSession.id}
              onChange={(e) => {
                setConfirmReset(false);
                setConfirmEnd(false);
                onSelectSession(e.target.value);
              }}
              className="h-9 px-3 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
            >
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.title} ({s.code})
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            onClick={() => onViewQr(selectedSession.id)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <QrCode className="w-3.5 h-3.5 text-blue-600" />
            Show QR Code
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            disabled={sessionSubmissions.length === 0}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>

          {confirmReset ? (
            <div className="inline-flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  onResetResponses(selectedSession.id);
                  setConfirmReset(false);
                }}
                className="px-3 py-2 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer whitespace-nowrap"
              >
                Confirm Reset
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              disabled={sessionSubmissions.length === 0}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed whitespace-nowrap"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
          )}

          {selectedSession.status === 'active' ? (
            confirmEnd ? (
              <div className="inline-flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setConfirmEnd(false);
                    onEndSession(selectedSession.id);
                  }}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer whitespace-nowrap"
                >
                  Confirm End Session
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmEnd(false)}
                  className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer whitespace-nowrap"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <motion.button
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={() => setConfirmEnd(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 rounded-lg shadow-xs transition-all cursor-pointer whitespace-nowrap"
              >
                <Power className="w-3.5 h-3.5" />
                End Session
              </motion.button>
            )
          ) : (
            <div className="inline-flex items-center gap-2">
              {onEditSession && (
                <button
                  type="button"
                  onClick={() => onEditSession(selectedSession.id)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer whitespace-nowrap"
                >
                  <Pencil className="w-3.5 h-3.5 text-blue-600" />
                  Edit Activity
                </button>
              )}
              {onReopenSession && (
                <motion.button
                  whileHover={{ y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  type="button"
                  onClick={() => onReopenSession(selectedSession.id)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-lg shadow-xs transition-all cursor-pointer whitespace-nowrap"
                >
                  <Play className="w-3.5 h-3.5" />
                  Reopen Activity
                </motion.button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Animated Live Status Bar with Emojis */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:px-6 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <motion.span
              aria-hidden="true"
              animate={
                selectedSession.status === 'active'
                  ? { scale: [1, 1.2, 1], rotate: [0, -8, 8, 0] }
                  : { scale: 1 }
              }
              transition={
                selectedSession.status === 'active'
                  ? { duration: 2.2, repeat: Infinity, ease: 'easeInOut' }
                  : undefined
              }
              className="text-2xl leading-none select-none shrink-0"
            >
              {selectedSession.status === 'active'
                ? sessionSubmissions.length > 0
                  ? '🎉'
                  : '📡'
                : '🏁'}
            </motion.span>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-slate-900 truncate">
                {selectedSession.status === 'active'
                  ? sessionSubmissions.length > 0
                    ? 'Live Status: Receiving responses in real time'
                    : 'Live Status: Ready and waiting for attendee scans'
                  : 'Live Status: Session ended and archived'}
              </p>
              <p className="text-xs text-slate-500">
                {selectedSession.status === 'active'
                  ? `Session #${selectedSession.code} is open for anonymous submissions`
                  : 'Final results snapshot recorded'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-slate-700 tabular-nums shrink-0">
            <motion.span
              key={sessionSubmissions.length}
              initial={{ scale: 1.25 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 400, damping: 20 }}
              aria-hidden="true"
              className="text-base"
            >
              {selectedSession.status === 'active' ? '✨' : '📊'}
            </motion.span>
            <span>
              {sessionSubmissions.length}{' '}
              {sessionSubmissions.length === 1 ? 'response' : 'responses'}
            </span>
          </div>
        </div>

        <div className="relative pt-1">
          <FlyingBarEmojis
            triggerValue={sessionSubmissions.length}
            continuous={
              selectedSession.status === 'active' && sessionSubmissions.length > 0
            }
            emojis={
              selectedSession.status === 'active'
                ? ['🎉', '✨', '🚀', '🌟', '🙌']
                : []
            }
          />
          <div className="relative w-full h-3 bg-slate-100 rounded-full overflow-hidden">
            {selectedSession.status === 'active' ? (
              <motion.div
                animate={{ x: ['-45%', '100%'] }}
                transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
                className="h-full w-1/2 rounded-full bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-500"
              />
            ) : (
              <div className="h-full w-full rounded-full bg-slate-300" />
            )}
          </div>
        </div>
      </div>

      {/* 4-Column Summary KPI Strip with Colorful Top Accents */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="h-1 bg-gradient-to-r from-sky-400 to-blue-600" />
          <div className="p-5">
            <span className="text-xs font-medium text-slate-500">Total Submissions</span>
            <p className="text-2xl font-bold text-slate-900 mt-1 font-mono tabular-nums">
              {sessionSubmissions.length}
            </p>
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="h-1 bg-gradient-to-r from-indigo-400 to-violet-600" />
          <div className="p-5">
            <span className="text-xs font-medium text-slate-500">Activity Mode</span>
            <p className="text-2xl font-bold text-slate-900 mt-1">{activityLabel}</p>
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="h-1 bg-gradient-to-r from-emerald-400 to-teal-600" />
          <div className="p-5">
            <span className="text-xs font-medium text-slate-500">Questions</span>
            <p className="text-2xl font-bold text-slate-900 mt-1 font-mono tabular-nums">
              {selectedSession.questions.length}
            </p>
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="h-1 bg-gradient-to-r from-amber-400 to-orange-600" />
          <div className="p-5">
            <span className="text-xs font-medium text-slate-500">
              {selectedSession.activityType === 'quiz' ? 'Avg Quiz Score' : 'Session Code'}
            </span>
            <p className="text-2xl font-bold text-slate-900 mt-1 font-mono tabular-nums">
              {selectedSession.activityType === 'quiz'
                ? avgQuizPct !== null
                  ? `${avgQuizPct}%`
                  : '—'
                : selectedSession.code}
            </p>
          </div>
        </div>
      </div>

      {/* Per-Question Live Results */}
      <div className="space-y-4">
        {selectedSession.questions.map((question, idx) => (
          <QuestionLiveResultCard
            key={question.id}
            index={idx}
            question={question}
            isQuiz={selectedSession.activityType === 'quiz'}
            submissions={sessionSubmissions}
          />
        ))}
      </div>
    </div>
  );
}

interface FlyingEmojiBurst {
  id: number;
  emoji: string;
  leftPct: number;
  driftX: number;
  rotate: number;
  delay: number;
}

function FlyingBarEmojis({
  triggerValue,
  continuous,
  emojis,
  maxWidthPct = 100,
}: {
  triggerValue: number;
  continuous: boolean;
  emojis: string[];
  maxWidthPct?: number;
}) {
  const prevValueRef = useRef<number>(triggerValue);
  const burstIdRef = useRef<number>(0);
  const [bursts, setBursts] = useState<FlyingEmojiBurst[]>([]);

  useEffect(() => {
    if (triggerValue > prevValueRef.current && emojis.length > 0) {
      const spanMax = Math.max(20, Math.min(92, maxWidthPct));
      const nextBursts: FlyingEmojiBurst[] = Array.from({ length: 5 }, (_, i) => {
        burstIdRef.current += 1;
        return {
          id: burstIdRef.current,
          emoji: emojis[i % emojis.length],
          leftPct: Math.min(92, 10 + (spanMax - 10) * ((i + 0.5) / 5)),
          driftX: (i % 2 === 0 ? 1 : -1) * (8 + i * 4),
          rotate: (i % 2 === 0 ? 1 : -1) * (10 + i * 3),
          delay: i * 0.08,
        };
      });
      setBursts((prev) => [...prev.slice(-10), ...nextBursts]);

      const cleanupTimer = setTimeout(() => {
        const ids = new Set(nextBursts.map((b) => b.id));
        setBursts((prev) => prev.filter((item) => !ids.has(item.id)));
      }, 1500);
      prevValueRef.current = triggerValue;
      return () => clearTimeout(cleanupTimer);
    }
    prevValueRef.current = triggerValue;
    return undefined;
  }, [triggerValue, emojis, maxWidthPct]);

  if (emojis.length === 0) return null;

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-x-0 -top-4 bottom-0 overflow-visible z-20"
    >
      {/* Continuous gliding emojis flying over populated/active status bars */}
      {continuous && (
        <>
          <motion.span
            animate={{
              left: ['2%', `${Math.max(24, Math.min(94, maxWidthPct))}%`],
              y: [0, -10, -2, -12, 0],
              opacity: [0, 1, 1, 1, 0],
              scale: [0.85, 1.15, 0.95, 1.1, 0.85],
            }}
            transition={{
              duration: 2.8,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="absolute top-0 text-base leading-none select-none"
          >
            {emojis[0]}
          </motion.span>
          {emojis.length > 1 && (
            <motion.span
              animate={{
                left: ['6%', `${Math.max(20, Math.min(90, maxWidthPct))}%`],
                y: [-2, -14, -4, -10, -2],
                opacity: [0, 0.95, 1, 0.95, 0],
                scale: [0.8, 1.1, 0.9, 1.05, 0.8],
              }}
              transition={{
                duration: 3.1,
                delay: 1.2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="absolute top-0 text-sm leading-none select-none"
            >
              {emojis[1]}
            </motion.span>
          )}
        </>
      )}

      {/* Burst of flying emojis whenever a bar count increases */}
      <AnimatePresence>
        {bursts.map((b) => (
          <motion.span
            key={b.id}
            initial={{ opacity: 0, y: 8, x: 0, scale: 0.5, rotate: 0 }}
            animate={{
              opacity: [0, 1, 1, 0],
              y: -30,
              x: b.driftX,
              scale: [0.6, 1.3, 0.95],
              rotate: b.rotate,
            }}
            exit={{ opacity: 0 }}
            transition={{
              duration: 1.25,
              delay: b.delay,
              ease: [0.16, 1, 0.3, 1],
            }}
            style={{ left: `${b.leftPct}%` }}
            className="absolute top-1 text-lg leading-none select-none"
          >
            {b.emoji}
          </motion.span>
        ))}
      </AnimatePresence>
    </div>
  );
}

const OPTION_BAR_COLORS = [
  'from-sky-500 to-blue-600',
  'from-violet-500 to-indigo-600',
  'from-amber-500 to-orange-600',
  'from-teal-500 to-emerald-600',
  'from-pink-500 to-rose-600',
  'from-cyan-500 to-sky-600',
];

const RATING_BAR_COLORS: Record<string, string> = {
  rate_excellent: 'from-emerald-500 to-teal-500',
  rate_very_good: 'from-sky-500 to-blue-600',
  rate_good: 'from-indigo-500 to-violet-600',
  rate_poor: 'from-amber-500 to-orange-500',
  rate_too_bad: 'from-rose-500 to-red-600',
};

const FALLBACK_OPTION_EMOJIS = ['🌟', '💡', '📊', '🎯', '🔥', '✨'];

function getOptionEmojiAndLabel(
  optId: string,
  text: string,
  optIdx: number
): { emoji: string; label: string } {
  const trimmed = text.trim();
  const emojiMatch = trimmed.match(
    /^(\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic})*)\s+(.*)$/u
  );
  if (emojiMatch) {
    return { emoji: emojiMatch[1], label: emojiMatch[2] || trimmed };
  }
  const lower = trimmed.toLowerCase();
  if (optId === 'yes' || lower === 'yes') return { emoji: '👍', label: trimmed };
  if (optId === 'no' || lower === 'no') return { emoji: '👎', label: trimmed };
  if (lower.includes('excellent')) return { emoji: '🤩', label: trimmed };
  if (lower.includes('very good') || lower.includes('verygood')) {
    return { emoji: '😊', label: trimmed };
  }
  if (lower === 'good') return { emoji: '🙂', label: trimmed };
  if (lower.includes('poor')) return { emoji: '😕', label: trimmed };
  if (lower.includes('too bad')) return { emoji: '😞', label: trimmed };
  return {
    emoji: FALLBACK_OPTION_EMOJIS[optIdx % FALLBACK_OPTION_EMOJIS.length],
    label: trimmed,
  };
}

function QuestionLiveResultCard({
  index,
  question,
  isQuiz,
  submissions,
}: {
  index: number;
  question: SessionQuestion;
  isQuiz: boolean;
  submissions: AttendeeSubmission[];
}) {
  const kindLabel =
    question.kind === 'yes_no'
      ? 'Yes / No'
      : question.kind === 'mcq'
        ? 'Multiple Choice'
        : 'Descriptive';

  if (question.kind === 'descriptive') {
    const textEntries = [...submissions]
      .map((s) => ({
        id: s.id,
        submittedAt: s.submittedAt,
        text:
          typeof s.answers[question.id] === 'string'
            ? (s.answers[question.id] as string).trim()
            : '',
      }))
      .filter((entry) => entry.text.length > 0)
      .sort((a, b) => b.submittedAt - a.submittedAt);

    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2, delay: index * 0.04 }}
        className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs"
      >
        <div className="flex items-center justify-between gap-2 px-6 py-3.5 bg-slate-50/80 border-b border-slate-200 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="font-mono font-semibold text-orange-600 tabular-nums">
              Q{index + 1}
            </span>
            <span aria-hidden="true">·</span>
            <span>{kindLabel}</span>
          </div>
          <span className="font-mono tabular-nums">
            {textEntries.length} {textEntries.length === 1 ? 'response' : 'responses'}
          </span>
        </div>

        <div className="p-6 space-y-4">
          <h3 className="text-base font-semibold text-slate-900 text-balance">
            {question.prompt}
          </h3>

          {textEntries.length === 0 ? (
            <p className="text-sm text-slate-500">
              No descriptive answers submitted yet. Responses will appear here live.
            </p>
          ) : (
            <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl bg-slate-50/40 max-h-72 overflow-y-auto">
              {textEntries.map((entry) => (
                <div key={entry.id} className="p-4 space-y-1">
                  <span className="block text-[11px] font-mono text-slate-400 tabular-nums">
                    {new Date(entry.submittedAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                  <p className="text-sm text-slate-800 leading-relaxed">{entry.text}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    );
  }

  const counts = question.options.map((opt) => {
    const count = submissions.filter((s) => {
      const val = s.answers[question.id];
      return Array.isArray(val) ? val.includes(opt.id) : val === opt.id;
    }).length;
    return { ...opt, count };
  });

  const totalSelections = counts.reduce((sum, c) => sum + c.count, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: index * 0.04 }}
      className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs"
    >
      <div className="flex items-center justify-between gap-2 px-6 py-3.5 bg-slate-50/80 border-b border-slate-200 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <span className="font-mono font-semibold text-blue-600 tabular-nums">
            Q{index + 1}
          </span>
          <span aria-hidden="true">·</span>
          <span>{kindLabel}</span>
        </div>
        <span className="font-mono tabular-nums">
          {submissions.length} {submissions.length === 1 ? 'submission' : 'submissions'}
        </span>
      </div>

      <div className="p-6 space-y-4">
        <h3 className="text-base font-semibold text-slate-900 text-balance">
          {question.prompt}
        </h3>

        {submissions.length === 0 ? (
          <p className="text-sm text-slate-500">
            Waiting for attendees to scan the QR code and respond.
          </p>
        ) : (
          <div className="space-y-4">
            {counts.map((opt, optIdx) => {
              const pct =
                totalSelections > 0
                  ? Math.round((opt.count / totalSelections) * 100)
                  : 0;
              const isCorrect = isQuiz && question.correctOptionId === opt.id;
              const isWrongSelected = isQuiz && !isCorrect && opt.count > 0;
              const barColor = isCorrect
                ? 'from-emerald-500 to-teal-500'
                : isWrongSelected
                  ? 'from-rose-500 to-red-500'
                  : RATING_BAR_COLORS[opt.id] ??
                    OPTION_BAR_COLORS[optIdx % OPTION_BAR_COLORS.length];
              const { emoji, label } = getOptionEmojiAndLabel(
                opt.id,
                opt.text,
                optIdx
              );
              const flyingEmojis = isCorrect
                ? ['✅', '🎉', '🏆', '🌟']
                : isWrongSelected
                  ? ['❌', '😅', '💨']
                  : [emoji, '✨', '🚀', '🎉'];

              return (
                <div key={opt.id} className="space-y-1.5">
                  <div className="flex items-center justify-between gap-4 text-sm">
                    <span className="inline-flex items-center gap-2 font-medium text-slate-800">
                      <motion.span
                        key={`${opt.id}-${opt.count}`}
                        initial={{ scale: 1.35, rotate: -10 }}
                        animate={
                          opt.count > 0
                            ? { scale: [1, 1.15, 1], rotate: [0, -5, 5, 0] }
                            : { scale: 1, rotate: 0 }
                        }
                        transition={{
                          duration: 2.2,
                          repeat: opt.count > 0 ? Infinity : 0,
                          repeatDelay: 1.5,
                          ease: 'easeInOut',
                        }}
                        aria-hidden="true"
                        className="text-lg leading-none select-none shrink-0"
                      >
                        {isCorrect ? '✅' : isWrongSelected ? '❌' : emoji}
                      </motion.span>
                      {isCorrect && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                      {isWrongSelected && (
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      )}
                      <span>{label}</span>
                      {isCorrect && (
                        <span className="text-xs font-semibold text-emerald-700">
                          Correct Answer 🏆
                        </span>
                      )}
                      {isWrongSelected && (
                        <span className="text-xs font-medium text-rose-600">
                          Wrong Option 😅
                        </span>
                      )}
                    </span>
                    <span className="font-mono text-xs text-slate-600 tabular-nums shrink-0">
                      {opt.count} ({pct}%)
                    </span>
                  </div>
                  <div className="relative pt-1">
                    <FlyingBarEmojis
                      triggerValue={opt.count}
                      continuous={pct > 0}
                      emojis={flyingEmojis}
                      maxWidthPct={pct}
                    />
                    <div className="relative w-full h-4 bg-slate-100 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                        className={`relative h-full rounded-full bg-gradient-to-r ${barColor} overflow-hidden`}
                      >
                        {pct > 0 && (
                          <motion.span
                            aria-hidden="true"
                            animate={{ x: ['-100%', '200%'] }}
                            transition={{
                              duration: 2.2,
                              repeat: Infinity,
                              ease: 'linear',
                            }}
                            className="absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                          />
                        )}
                      </motion.div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </motion.div>
  );
}
