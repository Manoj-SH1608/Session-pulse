import { useMemo, useState } from 'react';
import {
  Download,
  QrCode,
  Search,
  Trash2,
} from 'lucide-react';
import type {
  ActivityType,
  AttendeeSubmission,
  Session,
} from '../../types/session';
import { exportSessionSubmissionsCSV } from '../../lib/storage';

interface RecordsViewProps {
  sessions: Session[];
  submissions: AttendeeSubmission[];
  onOpenSessionBuilder: (sessionId: string) => void;
  onOpenSessionQr: (sessionId: string) => void;
  onOpenSessionResults: (sessionId: string) => void;
  onToggleSessionStatus: (sessionId: string) => void;
  onDeleteSession: (sessionId: string) => void;
}

export function RecordsView({
  sessions,
  submissions,
  onOpenSessionBuilder,
  onOpenSessionQr,
  onOpenSessionResults,
  onToggleSessionStatus,
  onDeleteSession,
}: RecordsViewProps) {
  const [filterType, setFilterType] = useState<'all' | ActivityType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [inspectedSessionId, setInspectedSessionId] = useState<string>(
    sessions[0]?.id ?? ''
  );
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const filteredSessions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return sessions.filter((s) => {
      if (filterType !== 'all' && s.activityType !== filterType) return false;
      if (!q) return true;
      return (
        s.title.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q) ||
        s.presenter.toLowerCase().includes(q)
      );
    });
  }, [sessions, filterType, searchQuery]);

  const inspectedSession =
    sessions.find((s) => s.id === inspectedSessionId) ?? filteredSessions[0];

  const inspectedSubmissions = useMemo(() => {
    if (!inspectedSession) return [];
    return [...submissions]
      .filter((sub) => sub.sessionId === inspectedSession.id)
      .sort((a, b) => b.submittedAt - a.submittedAt);
  }, [submissions, inspectedSession]);

  const handleDownloadCsv = (session: Session) => {
    const rows = submissions.filter((s) => s.sessionId === session.id);
    const csv = exportSessionSubmissionsCSV(session, rows);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sessionpulse-${session.code.toLowerCase()}-records.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header & Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Records</h2>
          <p className="text-sm text-slate-500">
            Browse all created Poll, Quiz, and Opinion sessions and inspect individual anonymous submission records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="inline-flex items-center gap-2 p-1.5 bg-slate-100 rounded-lg">
            {(
              [
                ['all', 'All'],
                ['poll', 'Polls'],
                ['quiz', 'Quizzes'],
                ['opinion', 'Opinions'],
              ] as ['all' | ActivityType, string][]
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setFilterType(key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-[transform,color,background-color] duration-200 ease-in-out hover:scale-110 whitespace-nowrap cursor-pointer ${
                  filterType === key
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search title or code..."
              className="pl-8 pr-3 py-1.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600 w-48"
            />
          </div>
        </div>
      </div>

      {/* Sessions Table */}
      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="h-1 w-full bg-gradient-to-r from-sky-500 via-indigo-500 to-amber-500" />
        {filteredSessions.length === 0 ? (
          <div className="p-10 text-center space-y-1">
            <p className="text-sm font-medium text-slate-900">No session records found</p>
            <p className="text-xs text-slate-500">
              Try clearing your filter or create a new session in the Session Builder tab.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                  <th className="py-3 px-4">Session Title</th>
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4 text-right">Questions</th>
                  <th className="py-3 px-4 text-right">Responses</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredSessions.map((s) => {
                  const count = submissions.filter((sub) => sub.sessionId === s.id).length;
                  const isInspected = inspectedSession?.id === s.id;
                  const typeLabel =
                    s.activityType === 'poll'
                      ? 'Poll'
                      : s.activityType === 'quiz'
                        ? 'Quiz'
                        : 'Opinion';
                  const typeColor =
                    s.activityType === 'poll'
                      ? 'text-blue-700 font-semibold'
                      : s.activityType === 'quiz'
                        ? 'text-emerald-700 font-semibold'
                        : 'text-orange-600 font-semibold';

                  return (
                    <tr
                      key={s.id}
                      onClick={() => setInspectedSessionId(s.id)}
                      className={`transition-colors cursor-pointer ${
                        isInspected ? 'bg-blue-50/50' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3 px-4 font-medium text-slate-900 max-w-[240px] truncate">
                        {s.title}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700 tabular-nums">
                        {s.code}
                      </td>
                      <td className={`py-3 px-4 ${typeColor}`}>{typeLabel}</td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700 tabular-nums">
                        {s.questions.length}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                        {count}
                      </td>
                      <td className="py-3 px-4">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleSessionStatus(s.id);
                          }}
                          className={`text-xs font-medium cursor-pointer hover:underline ${
                            s.status === 'active'
                              ? 'text-emerald-700'
                              : 'text-slate-500'
                          }`}
                        >
                          {s.status === 'active' ? 'Active' : 'Ended'}
                        </button>
                      </td>
                      <td
                        className="py-3 px-4 text-right"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="inline-flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => onOpenSessionBuilder(s.id)}
                            className="text-slate-700 hover:text-blue-600 font-medium whitespace-nowrap cursor-pointer"
                          >
                            {s.status === 'ended' ? 'Edit / Reopen' : 'Edit'}
                          </button>
                          <button
                            type="button"
                            onClick={() => onOpenSessionQr(s.id)}
                            aria-label="Show QR Code"
                            className="text-slate-700 hover:text-blue-600 inline-flex items-center gap-1 font-medium whitespace-nowrap cursor-pointer"
                          >
                            <QrCode className="w-3.5 h-3.5" />
                            QR
                          </button>
                          <button
                            type="button"
                            onClick={() => onOpenSessionResults(s.id)}
                            className="text-slate-700 hover:text-blue-600 font-medium whitespace-nowrap cursor-pointer"
                          >
                            Results
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDownloadCsv(s)}
                            aria-label="Export CSV"
                            className="text-slate-500 hover:text-slate-900 cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          {confirmDeleteId === s.id ? (
                            <span className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  onDeleteSession(s.id);
                                  setConfirmDeleteId(null);
                                }}
                                className="text-red-600 font-semibold cursor-pointer"
                              >
                                Confirm
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="text-slate-500 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(s.id)}
                              aria-label="Delete session"
                              className="text-slate-400 hover:text-red-600 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Individual Submission Records Log for Selected Session */}
      {inspectedSession && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 bg-slate-50/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Individual Response Records — {inspectedSession.title}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                {inspectedSubmissions.length}{' '}
                {inspectedSubmissions.length === 1 ? 'submission' : 'submissions'} recorded
                anonymously
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleDownloadCsv(inspectedSession)}
              disabled={inspectedSubmissions.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Download Session CSV
            </button>
          </div>

          {inspectedSubmissions.length === 0 ? (
            <p className="p-6 text-sm text-slate-500">
              No anonymous submissions recorded for this session yet.
            </p>
          ) : (
            <div className="divide-y divide-slate-200">
              {inspectedSubmissions.map((sub, rIdx) => (
                <div key={sub.id} className="p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="font-mono font-semibold text-slate-800 tabular-nums">
                      Response #{inspectedSubmissions.length - rIdx}
                    </span>
                    <div className="flex items-center gap-3">
                      {sub.quizScore && (
                        <span className="font-mono font-medium text-emerald-700 tabular-nums">
                          Quiz Score: {sub.quizScore.score}/{sub.quizScore.total}
                        </span>
                      )}
                      <span className="font-mono tabular-nums">
                        {new Date(sub.submittedAt).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {inspectedSession.questions.map((q, qIdx) => {
                      const raw = sub.answers[q.id];
                      let displayAnswer = '—';
                      if (q.kind === 'descriptive') {
                        displayAnswer =
                          typeof raw === 'string' && raw.trim() ? raw : '—';
                      } else if (Array.isArray(raw)) {
                        displayAnswer = raw
                          .map((oid) => q.options.find((o) => o.id === oid)?.text ?? oid)
                          .join(', ');
                      } else if (typeof raw === 'string') {
                        displayAnswer = q.options.find((o) => o.id === raw)?.text ?? raw;
                      }

                      return (
                        <div
                          key={q.id}
                          className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg space-y-1"
                        >
                          <p className="text-[11px] font-medium text-slate-500">
                            Q{qIdx + 1}. {q.prompt}
                          </p>
                          <p className="text-xs font-medium text-slate-900">
                            {displayAnswer}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
