import { useEffect, useMemo, useState } from 'react';
import { Download, LogOut, User } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type {
  AttendeeSubmission,
  Session,
  SessionPulseStore,
} from './types/session';
import {
  apiCreateSession,
  apiDeleteSession,
  apiResetSessionResponses,
  apiSubmitResponse,
  apiUpdateSession,
  cacheStoreLocally,
  fetchServerStore,
  loadStore,
  parseAttendeeRouteFromUrl,
  saveStore,
  subscribeToServerEvents,
  subscribeToStore,
  type SubmitResponseResult,
} from './lib/storage';
import { AdminLogin } from './components/admin/AdminLogin';
import {
  SessionBuilderWizard,
  type BuilderStep,
} from './components/admin/SessionBuilderWizard';
import { LiveResultsView } from './components/admin/LiveResultsView';
import { RecordsView } from './components/admin/RecordsView';
import { AttendeeView } from './components/attendee/AttendeeView';

type AdminNavTab = 'builder' | 'results' | 'records';

export default function App() {
  const initialRoute = useMemo(() => parseAttendeeRouteFromUrl(), []);
  const initialQuery = initialRoute.sessionQuery;

  const [store, setStore] = useState<SessionPulseStore>(() => loadStore());
  const [adminEmail, setAdminEmail] = useState<string | null>(null);
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [downloadingCode, setDownloadingCode] = useState(false);
  const [mode, setMode] = useState<'admin' | 'attendee'>(
    initialQuery ? 'attendee' : 'admin'
  );

  // 3 Admin navbar tabs: Session Builder, Live Results, Records
  const [activeTab, setActiveTab] = useState<AdminNavTab>('builder');
  const [builderStep, setBuilderStep] = useState<BuilderStep>('setup');
  const [builderSessionId, setBuilderSessionId] = useState<string | null>(null);
  const [resultsSessionId, setResultsSessionId] = useState<string>('');

  // Server hydration + real-time cross-device SSE & cross-tab BroadcastChannel sync
  useEffect(() => {
    let active = true;
    const syncFromServer = async () => {
      const serverStore = await fetchServerStore();
      if (active && serverStore) {
        setStore(serverStore);
        cacheStoreLocally(serverStore);
      }
    };

    void syncFromServer();
    const unsubEvents = subscribeToServerEvents(() => {
      void syncFromServer();
    });
    const unsubLocal = subscribeToStore((nextStore) => {
      setStore(nextStore);
    });

    return () => {
      active = false;
      unsubEvents();
      unsubLocal();
    };
  }, []);

  const persistStore = (updater: (prev: SessionPulseStore) => SessionPulseStore) => {
    setStore((prev) => {
      const next = updater(prev);
      saveStore(next);
      return next;
    });
  };

  const handleCreateSession = (created: Session) => {
    persistStore((prev) => ({
      ...prev,
      sessions: [created, ...prev.sessions],
    }));
    void apiCreateSession(created);
    setBuilderSessionId(created.id);
    setResultsSessionId(created.id);
  };

  const handleUpdateSession = (updated: Session, immediate = false) => {
    persistStore((prev) => ({
      ...prev,
      sessions: prev.sessions.map((s) => (s.id === updated.id ? updated : s)),
    }));
    void apiUpdateSession(updated, immediate);
  };

  const handleReopenSession = (sessionId: string) => {
    let reopened: Session | undefined;
    persistStore((prev) => ({
      ...prev,
      sessions: prev.sessions.map((s) => {
        if (s.id !== sessionId) return s;
        reopened = { ...s, status: 'active' };
        return reopened;
      }),
    }));
    if (reopened) {
      void apiUpdateSession(reopened, true);
    }
  };

  const handleDeleteSession = (sessionId: string) => {
    persistStore((prev) => {
      const remaining = prev.sessions.filter((s) => s.id !== sessionId);
      if (builderSessionId === sessionId) {
        setBuilderSessionId(null);
        setBuilderStep('setup');
      }
      if (resultsSessionId === sessionId) {
        const nextActive = remaining.find((s) => s.status === 'active');
        setResultsSessionId(nextActive?.id ?? '');
      }
      return {
        sessions: remaining,
        submissions: prev.submissions.filter((sub) => sub.sessionId !== sessionId),
      };
    });
    void apiDeleteSession(sessionId);
  };

  const handleToggleStatus = (sessionId: string) => {
    let updatedSession: Session | undefined;
    persistStore((prev) => ({
      ...prev,
      sessions: prev.sessions.map((s) => {
        if (s.id !== sessionId) return s;
        updatedSession = {
          ...s,
          status: s.status === 'active' ? 'ended' : 'active',
        };
        return updatedSession;
      }),
    }));
    if (updatedSession) {
      void apiUpdateSession(updatedSession, true);
    }
  };

  const handleEndSessionFromLiveResults = (sessionId: string) => {
    let endedSession: Session | undefined;
    persistStore((prev) => ({
      ...prev,
      sessions: prev.sessions.map((s) => {
        if (s.id !== sessionId) return s;
        endedSession = { ...s, status: 'ended' };
        return endedSession;
      }),
    }));
    if (endedSession) {
      void apiUpdateSession(endedSession, true);
    }
    setBuilderSessionId(null);
    setBuilderStep('setup');
    setResultsSessionId('');
    setActiveTab('builder');
  };

  const handleResetResponses = (sessionId: string) => {
    persistStore((prev) => ({
      ...prev,
      submissions: prev.submissions.filter((sub) => sub.sessionId !== sessionId),
    }));
    void apiResetSessionResponses(sessionId);
  };

  const handleSubmitAttendeeResponse = async (
    submission: AttendeeSubmission
  ): Promise<SubmitResponseResult> => {
    const result = await apiSubmitResponse(submission);
    if (result.ok) {
      persistStore((prev) => ({
        ...prev,
        submissions: [...prev.submissions, submission],
      }));
    }
    return result;
  };

  const openSessionInBuilder = (sessionId: string, targetStep: BuilderStep) => {
    setBuilderSessionId(sessionId);
    setResultsSessionId(sessionId);
    setBuilderStep(targetStep);
    setActiveTab('builder');
  };

  const openSessionInResults = (sessionId: string) => {
    setResultsSessionId(sessionId);
    setActiveTab('results');
  };

  // Public Attendee Route (QR scan target — never blocked by admin login and has zero access to admin portal)
  if (mode === 'attendee') {
    return (
      <AttendeeView
        sessions={store.sessions}
        initialSessionQuery={
          initialQuery ?? (builderSessionId || resultsSessionId || store.sessions[0]?.id || null)
        }
        fallbackSession={initialRoute.fallbackSession}
        onSubmitResponse={handleSubmitAttendeeResponse}
        onExitToAdmin={
          adminEmail && !initialQuery ? () => setMode('admin') : undefined
        }
      />
    );
  }

  // Admin Portal Authentication Gate
  if (!adminEmail) {
    return (
      <AdminLogin
        onLoginSuccess={(email, token) => {
          setAdminEmail(email);
          setAdminToken(token ?? null);
          setBuilderSessionId(null);
          setBuilderStep('setup');
          setActiveTab('builder');
        }}
      />
    );
  }

  const activeBuilderSession = builderSessionId
    ? store.sessions.find((s) => s.id === builderSessionId) ?? null
    : null;

  const activeResultsSession =
    (resultsSessionId
      ? store.sessions.find((s) => s.id === resultsSessionId)
      : undefined) ?? store.sessions.find((s) => s.status === 'active');

  const navItems: { id: AdminNavTab; label: string }[] = [
    { id: 'builder', label: 'Session Builder' },
    { id: 'results', label: 'Live Results' },
    { id: 'records', label: 'Records' },
  ];

  return (
    <div className="min-h-screen studio-canvas flex flex-col">
      {/* 3-Zone Top Bar: Wordmark — 3 Animated Navbar Tabs — User Profile & Sign Out */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/90 px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('builder');
          }}
          className="font-display text-lg font-bold tracking-tight bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 bg-clip-text text-transparent whitespace-nowrap shrink-0"
        >
          SessionPulse
        </a>

        <nav
          aria-label="Admin navigation"
          className="hidden md:flex items-center gap-4 text-sm font-medium"
        >
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`relative px-4 py-2 rounded-lg transition-[transform,color,background-color] duration-200 ease-in-out hover:scale-110 whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'text-blue-700 font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="admin-nav-active-bg"
                    transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    className="absolute inset-0 bg-blue-50 border border-blue-200/80 rounded-lg -z-10"
                  />
                )}
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-2.5 shrink-0">
          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-700 mr-1">
            <span className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white flex items-center justify-center shrink-0">
              <User className="w-3.5 h-3.5" />
            </span>
            <span className="font-medium text-slate-800 max-w-[180px] truncate">
              {adminEmail}
            </span>
          </div>
          {adminToken && (
            <button
              type="button"
              disabled={downloadingCode}
              onClick={async () => {
                setDownloadingCode(true);
                try {
                  const res = await fetch('/api/admin/download-code', {
                    headers: { Authorization: `Bearer ${adminToken}` },
                  });
                  if (!res.ok) return;
                  const blob = await res.blob();
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = 'sessionpulse-code.zip';
                  link.click();
                  URL.revokeObjectURL(url);
                } finally {
                  setDownloadingCode(false);
                }
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-blue-700 bg-blue-50 border border-blue-200 hover:bg-blue-100 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              {downloadingCode ? 'Preparing...' : 'Download Code'}
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setAdminEmail(null);
              setAdminToken(null);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:border-slate-400 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </header>

      {/* Mobile Nav Strip */}
      <div className="md:hidden bg-white border-b border-slate-200 px-4 py-2.5 flex items-center gap-3 overflow-x-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveTab(item.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 cursor-pointer transition-[transform,color,background-color] duration-200 ease-in-out hover:scale-110 ${
              activeTab === item.id
                ? 'bg-blue-600 text-white'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Main Content Viewport with Smooth Tab Transitions */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <div className="max-w-5xl mx-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'builder' && (
              <motion.div
                key="tab-builder"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              >
                <SessionBuilderWizard
                  session={activeBuilderSession}
                  step={builderStep}
                  existingCodes={store.sessions.map((s) => s.code)}
                  submissionCount={
                    activeBuilderSession
                      ? store.submissions.filter(
                          (sub) => sub.sessionId === activeBuilderSession.id
                        ).length
                      : 0
                  }
                  onStepChange={setBuilderStep}
                  onCreateSession={handleCreateSession}
                  onUpdateSession={handleUpdateSession}
                  onReopenSession={handleReopenSession}
                  onGoToResults={() => {
                    if (activeBuilderSession) {
                      setResultsSessionId(activeBuilderSession.id);
                    }
                    setActiveTab('results');
                  }}
                  onPreviewAttendeeFullScreen={() => setMode('attendee')}
                />
              </motion.div>
            )}

            {activeTab === 'results' && (
              <motion.div
                key="tab-results"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              >
                <LiveResultsView
                  sessions={store.sessions}
                  selectedSession={activeResultsSession}
                  submissions={store.submissions}
                  onSelectSession={(id) => setResultsSessionId(id)}
                  onResetResponses={handleResetResponses}
                  onEndSession={handleEndSessionFromLiveResults}
                  onReopenSession={handleReopenSession}
                  onEditSession={(id) => openSessionInBuilder(id, 'questions')}
                  onViewQr={(id) => openSessionInBuilder(id, 'qr')}
                  onGoToBuilder={() => {
                    setBuilderSessionId(null);
                    setBuilderStep('setup');
                    setActiveTab('builder');
                  }}
                />
              </motion.div>
            )}

            {activeTab === 'records' && (
              <motion.div
                key="tab-records"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              >
                <RecordsView
                  sessions={store.sessions}
                  submissions={store.submissions}
                  onOpenSessionBuilder={(id) => openSessionInBuilder(id, 'questions')}
                  onOpenSessionQr={(id) => openSessionInBuilder(id, 'qr')}
                  onOpenSessionResults={openSessionInResults}
                  onToggleSessionStatus={handleToggleStatus}
                  onDeleteSession={handleDeleteSession}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
